# multiAgents.py
# --------------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


from util import manhattanDistance
from game import Directions
import random, util

from game import Agent

class ReflexAgent(Agent):
	"""
	A reflex agent chooses an action at each choice point by examining
	its alternatives via a state evaluation function.

	The code below is provided as a guide.  You are welcome to change
	it in any way you see fit, so long as you don't touch our method
	headers.
	"""


	def getAction(self, gameState):
		"""
		You do not need to change this method, but you're welcome to.

		getAction chooses among the best options according to the evaluation function.

		Just like in the previous project, getAction takes a GameState and returns
		some Directions.X for some X in the set {NORTH, SOUTH, WEST, EAST, STOP}
		"""
		# Collect legal moves and successor states
		legalMoves = gameState.getLegalActions()

		# Choose one of the best actions
		scores = [self.evaluationFunction(gameState, action) for action in legalMoves]
		bestScore = max(scores)
		bestIndices = [index for index in range(len(scores)) if scores[index] == bestScore]
		chosenIndex = random.choice(bestIndices) # Pick randomly among the best

		"Add more of your code here if you want to"
		# Name: Guru Sarath
		# UIN: 829009551

		return legalMoves[chosenIndex]

	def evaluationFunction(self, currentGameState, action):
		"""
		Design a better evaluation function here.

		The evaluation function takes in the current and proposed successor
		GameStates (pacman.py) and returns a number, where higher numbers are better.

		The code below extracts some useful information from the state, like the
		remaining food (newFood) and Pacman position after moving (newPos).
		newScaredTimes holds the number of moves that each ghost will remain
		scared because of Pacman having eaten a power pellet.

		Print out these variables to see what you're getting, then combine them
		to create a masterful evaluation function.
		"""
		# Useful information you can extract from a GameState (pacman.py)
		successorGameState = currentGameState.generatePacmanSuccessor(action)
		newPos = successorGameState.getPacmanPosition()
		newFood = successorGameState.getFood()
		Food = currentGameState.getFood()
		Food_List = Food.asList()
		newGhostStates = successorGameState.getGhostStates()
		newScaredTimes = [ghostState.scaredTimer for ghostState in newGhostStates]
		
		Score = 1000

		newGhostPos = successorGameState.getGhostPositions()
		
		i = 0
		
		# Score based on the distance from the ghost
		for GhostPosX in newGhostPos:
			Dist = util.manhattanDistance(GhostPosX, newPos)
			
			if newScaredTimes[i] == 0:
				if Dist < 2:
					Score -= 500
				elif Dist < 5:
					Score -= 10
				elif Dist < 10:
					Score -= 5
				else:
					Score -= 2		
			i += 1
			
		if Food[newPos[0]][newPos[1]]:
			Score += 20
		
		DistSum = 0
		for foodX in Food_List:
			DistSum += util.manhattanDistance(foodX, newPos)
		
		AvgDist = (DistSum / len(Food_List))

		Score -= AvgDist
		return Score

def scoreEvaluationFunction(currentGameState):
	"""
	This default evaluation function just returns the score of the state.
	The score is the same one displayed in the Pacman GUI.

	This evaluation function is meant for use with adversarial search agents
	(not reflex agents).
	"""
	return currentGameState.getScore()

class MultiAgentSearchAgent(Agent):
	"""
	This class provides some common elements to all of your
	multi-agent searchers.  Any methods defined here will be available
	to the MinimaxPacmanAgent, AlphaBetaPacmanAgent & ExpectimaxPacmanAgent.

	You *do not* need to make any changes here, but you can if you want to
	add functionality to all your adversarial search agents.  Please do not
	remove anything, however.

	Note: this is an abstract class: one that should not be instantiated.  It's
	only partially specified, and designed to be extended.  Agent (game.py)
	is another abstract class.
	"""

	def __init__(self, evalFn = 'scoreEvaluationFunction', depth = '2'):
		self.index = 0 # Pacman is always agent index 0
		self.evaluationFunction = util.lookup(evalFn, globals())
		self.depth = int(depth)

class MinimaxAgent(MultiAgentSearchAgent):
	"""
	Your minimax agent (question 2)
	"""

	def getAction(self, gameState):
		"""
		Returns the minimax action from the current gameState using self.depth
		and self.evaluationFunction.

		Here are some method calls that might be useful when implementing minimax.

		gameState.getLegalActions(agentIndex):
		Returns a list of legal actions for an agent
		agentIndex=0 means Pacman, ghosts are >= 1

		gameState.generateSuccessor(agentIndex, action):
		Returns the successor game state after an agent takes an action

		gameState.getNumAgents():
		Returns the total number of agents in the game

		gameState.isWin():
		Returns whether or not the game state is a winning state

		gameState.isLose():
		Returns whether or not the game state is a losing state
		"""
		
		
		NextAgentX = self.NextAgent(self.index, gameState)
		NextActions = gameState.getLegalActions(self.index)
		
		MaxVal = float('-inf')
		MaxAct = None
		for actX in NextActions:
			StateX = gameState.generateSuccessor(self.index, actX)
			Val = self.MinNode(StateX, self.depth, NextAgentX)
			
			#Update the max value if new better branch found
			if MaxVal < Val:
				MaxVal = Val
				MaxAct  = actX
		
		return MaxAct
				
	def MaxNode(self, gameState, depth, agentIndex):
	
		#print('Max Node', depth, agentIndex)
		#Decrement depth only if the agent is pacman
		if agentIndex == 0:
			depth -= 1
			
		#Terminal test
		if depth == 0 or gameState.isWin() or gameState.isLose():
			
			return self.evaluationFunction(gameState)

		
		NextAgentX = self.NextAgent(agentIndex, gameState)
		NextActions = gameState.getLegalActions(agentIndex)
		
		MaxVal = float('-inf')
		MaxAct = None
		
		for actX in NextActions:
			StateX = gameState.generateSuccessor(agentIndex, actX)
			Val = self.MinNode(StateX, depth, NextAgentX)
			if MaxVal < Val:
				MaxVal = Val
				MaxAct  = actX
		
		return MaxVal
				
	def MinNode(self, gameState, depth, agentIndex):
	
		#print('Min Node', depth, agentIndex)
		#Decrement depth only if the agent is pacman
		if agentIndex == 0:
			depth -= 1

		#Terminal test
		if depth == 0 or gameState.isWin() or gameState.isLose():
			
			return self.evaluationFunction(gameState)
		
		NextAgentX = self.NextAgent(agentIndex, gameState)
		NextActions = gameState.getLegalActions(agentIndex)
		
		MinVal = float('inf')
		MinAct = None
		
		for actX in NextActions:

			StateX = gameState.generateSuccessor(agentIndex, actX)
			
			if NextAgentX == 0:
				Val = self.MaxNode(StateX, depth, NextAgentX)
			else:
				Val = self.MinNode(StateX, depth, NextAgentX)
				
			if MinVal > Val:
				MinVal = Val
				MinAct  = actX
		
		return MinVal
	
	#Function that returns the next agent index
	def NextAgent(self, agentIndex, gameState):
		
		agentIndex += 1
		
		if agentIndex < gameState.getNumAgents():
			return agentIndex
		else:
			return 0

class AlphaBetaAgent(MultiAgentSearchAgent):
	"""
	Your minimax agent with alpha-beta pruning (question 3)
	"""

	def getAction(self, gameState):
		"""
		Returns the minimax action using self.depth and self.evaluationFunction
		"""
		
		Alpha = float('-inf')
		Beta = float('inf')
		
		NextAgentX = self.NextAgent(self.index, gameState)
		NextActions = gameState.getLegalActions(self.index)
		
		MaxVal = float('-inf')
		MaxAct = None
		for actX in NextActions:
			StateX = gameState.generateSuccessor(self.index, actX)
			Val = self.MinNode(StateX, self.depth, NextAgentX, Alpha, Beta)
			if MaxVal < Val:
				MaxVal = Val
				MaxAct  = actX
				
			if Alpha < MaxVal:
				Alpha = MaxVal
		
		return MaxAct
				
	def MaxNode(self, gameState, depth, agentIndex, Alpha, Beta):
	
		#print('Max Node', depth, agentIndex)
		#Decrement depth only if the agent is pacman
		if agentIndex == 0:
			depth -= 1

		#Terminal test
		if depth == 0 or gameState.isWin() or gameState.isLose():
			
			return self.evaluationFunction(gameState)
		
		NextAgentX = self.NextAgent(agentIndex, gameState)
		NextActions = gameState.getLegalActions(agentIndex)
		
		MaxVal = float('-inf')
		MaxAct = None
		
		for actX in NextActions:
			StateX = gameState.generateSuccessor(agentIndex, actX)
			Val = self.MinNode(StateX, depth, NextAgentX, Alpha, Beta)
			if MaxVal < Val:
				MaxVal = Val
				MaxAct  = actX
			
			if MaxVal > Beta:
				return MaxVal
				
			if Alpha < MaxVal:
				Alpha = MaxVal
				
		return MaxVal
				
	def MinNode(self, gameState, depth, agentIndex, Alpha, Beta):
	
		#print('Min Node', depth, agentIndex)
		#Decrement depth only if the agent is pacman
		if agentIndex == 0:
			depth -= 1

		#Terminal test
		if depth == 0 or gameState.isWin() or gameState.isLose():
			
			return self.evaluationFunction(gameState)
		
		NextAgentX = self.NextAgent(agentIndex, gameState)
		NextActions = gameState.getLegalActions(agentIndex)
		
		MinVal = float('inf')
		MaxVal = float('-inf')
		MinAct = None
		MaxAct = None
		
		for actX in NextActions:

			StateX = gameState.generateSuccessor(agentIndex, actX)
			
			if NextAgentX == 0:
				Val = self.MaxNode(StateX, depth, NextAgentX, Alpha, Beta)
			else:
				Val = self.MinNode(StateX, depth, NextAgentX, Alpha, Beta)
				
			if MinVal > Val:
				MinVal = Val
				MinAct  = actX
				
			if MinVal < Alpha:
				return MinVal
					
			if Beta > MinVal:
				Beta = MinVal		

		return MinVal

	#Function that returns the next agent index	
	def NextAgent(self, agentIndex, gameState):
		
		agentIndex += 1
		
		if agentIndex < gameState.getNumAgents():
			return agentIndex
		else:
			return 0

class ExpectimaxAgent(MultiAgentSearchAgent):
	"""
	  Your expectimax agent (question 4)
	"""

	def getAction(self, gameState):
		"""
		Returns the expectimax action using self.depth and self.evaluationFunction

		All ghosts should be modeled as choosing uniformly at random from their
		legal moves.
		"""
		NextAgentX = self.NextAgent(self.index, gameState)
		NextActions = gameState.getLegalActions(self.index)
		
		MaxVal = float('-inf')
		MaxAct = None
		for actX in NextActions:
			StateX = gameState.generateSuccessor(self.index, actX)
			Val = self.ExpectiNode(StateX, self.depth, NextAgentX)
			if MaxVal < Val:
				MaxVal = Val
				MaxAct  = actX
		
		return MaxAct
				
	def MaxNode(self, gameState, depth, agentIndex):
	
		#print('Max Node', depth, agentIndex)
		#Decrement depth only if the agent is pacman
		if agentIndex == 0:
			depth -= 1

		#Terminal test
		if depth == 0 or gameState.isWin() or gameState.isLose():
			
			return self.evaluationFunction(gameState)
		
		NextAgentX = self.NextAgent(agentIndex, gameState)
		NextActions = gameState.getLegalActions(agentIndex)
		
		MaxVal = float('-inf')
		MaxAct = None
		
		for actX in NextActions:
			StateX = gameState.generateSuccessor(agentIndex, actX)
			Val = self.ExpectiNode(StateX, depth, NextAgentX)
			if MaxVal < Val:
				MaxVal = Val
				MaxAct  = actX
		
		return MaxVal
				
	def ExpectiNode(self, gameState, depth, agentIndex):
	
		#print('Min Node', depth, agentIndex)
		#Decrement depth only if the agent is pacman
		if agentIndex == 0:
			depth -= 1

		#Terminal test
		if depth == 0 or gameState.isWin() or gameState.isLose():
			
			return self.evaluationFunction(gameState)
		
		NextAgentX = self.NextAgent(agentIndex, gameState)
		NextActions = gameState.getLegalActions(agentIndex)
		
		MinVal = float('inf')
		MinAct = None
		Sum = 0 #Sum of utilities of all states
		
		#Uniform probability distribution
		p = 1 / len(NextActions)
		
		for actX in NextActions:

			StateX = gameState.generateSuccessor(agentIndex, actX)
			
			if NextAgentX == 0:
				Val = self.MaxNode(StateX, depth, NextAgentX)
			else:
				Val = self.ExpectiNode(StateX, depth, NextAgentX)
				
			Sum += Val
		
		return Sum * p
	
	#Function that returns the next agent index	
	def NextAgent(self, agentIndex, gameState):
		
		agentIndex += 1
		
		if agentIndex < gameState.getNumAgents():
			return agentIndex
		else:
			return 0

def betterEvaluationFunction(currentGameState):
	"""
	Your extreme ghost-hunting, pellet-nabbing, food-gobbling, unstoppable
	evaluation function (question 5).

	DESCRIPTION: Consider different features of the state, weight it and sum it.
	"""
	PacPos = currentGameState.getPacmanPosition()
	FoodGrid = currentGameState.getFood()
	Food_List = FoodGrid.asList()
	newGhostStates = currentGameState.getGhostStates()
	ScaredTimes = [ghostState.scaredTimer for ghostState in newGhostStates]
	GostPos_s = currentGameState.getGhostPositions()
	
	
	weigth_score = 10
	weigth_ghost = -10
	weight_scareTime = 0.5
	
	score = currentGameState.getScore()
	
	Dist = [manhattanDistance(PacPos, ghostX) for ghostX in GostPos_s]
	ghost  = sum(Dist)
	
	scareTime = sum(ScaredTimes)
	
	return (weigth_score * score + weigth_ghost * ghost + weight_scareTime * scareTime)

# Abbreviation
better = betterEvaluationFunction
