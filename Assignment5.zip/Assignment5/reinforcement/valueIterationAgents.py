# valueIterationAgents.py
# -----------------------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


# valueIterationAgents.py
# -----------------------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


import mdp, util

from learningAgents import ValueEstimationAgent
import collections

class ValueIterationAgent(ValueEstimationAgent):
	"""
		* Please read learningAgents.py before reading this.*

		A ValueIterationAgent takes a Markov decision process
		(see mdp.py) on initialization and runs value iteration
		for a given number of iterations using the supplied
		discount factor.
	"""
	def __init__(self, mdp, discount = 0.9, iterations = 100):
		"""
		  Your value iteration agent should take an mdp on
		  construction, run the indicated number of iterations
		  and then act according to the resulting policy.

		  Some useful mdp methods you will use:
			  mdp.getStates()
			  mdp.getPossibleActions(state)
			  mdp.getTransitionStatesAndProbs(state, action)
			  mdp.getReward(state, action, nextState)
			  mdp.isTerminal(state)
		"""
		self.mdp = mdp
		self.discount = discount
		self.iterations = iterations
		self.values = util.Counter() # A Counter is a dict with default 0
		self.runValueIteration()

	def runValueIteration(self):
		# Write value iteration code here
		
		ValuesTemp = util.Counter()
		
		#Iterations loop
		for k in range(self.iterations):
		
			#Get Values of all states
			for stateX in self.mdp.getStates():

				allSums = []
				
				#Calculate Q values of all the states
				for actionX in self.mdp.getPossibleActions(stateX):
					S_T_pairs = self.mdp.getTransitionStatesAndProbs(stateX, actionX)
					Sum = 0
					for nextStateX, T_x  in S_T_pairs:
						R_x = self.mdp.getReward(stateX, actionX, nextStateX)
						#Bellman Equation
						Sum += T_x * (R_x + self.discount * self.values[nextStateX])
					allSums.append(Sum)

				
				if allSums:
					# V = Maximum Q value
					ValuesTemp[stateX] = max(allSums)
				else:
					# If terminal state
					ValuesTemp[stateX] = 0
					
			# Update all values in class variable	
			for stateX in self.mdp.getStates():
				self.values[stateX] = ValuesTemp[stateX]

	def getValue(self, state):
		"""
		  Return the value of the state (computed in __init__).
		"""
		return self.values[state]


	def computeQValueFromValues(self, state, action):
		"""
		  Compute the Q-value of action in state from the
		  value function stored in self.values.
		"""
		stateX = state
		actionX = action

		S_T_pairs = self.mdp.getTransitionStatesAndProbs(stateX, actionX)
		Sum = 0
		# Fall all the next states
		for nextStateX, T_x  in S_T_pairs:
			R_x = self.mdp.getReward(stateX, actionX, nextStateX)
			Sum = Sum + (T_x * (R_x + self.discount * self.values[nextStateX]))
		
		return Sum



	def computeActionFromValues(self, state):
		"""
		  The policy is the best action in the given state
		  according to the values currently stored in self.values.

		  You may break ties any way you see fit.  Note that if
		  there are no legal actions, which is the case at the
		  terminal state, you should return None.
		"""
		
		if self.mdp.isTerminal(state):
			return None
		else:
		# If not a terminal state
			stateX = state
			
			actions = self.mdp.getPossibleActions(stateX)
			BestQ = float('-inf')
			BestAct = None
			
			#Iterate through all the actions and find Q values
			for actionX in actions:
			
				Q_val = self.computeQValueFromValues(stateX, actionX)
				
				if BestQ < Q_val:
					BestQ = Q_val
					BestAct = actionX
		#Return the action with highest Q value
		return BestAct
			
			

	def getPolicy(self, state):
		return self.computeActionFromValues(state)

	def getAction(self, state):
		"Returns the policy at the state (no exploration)."
		return self.computeActionFromValues(state)

	def getQValue(self, state, action):
		return self.computeQValueFromValues(state, action)

class AsynchronousValueIterationAgent(ValueIterationAgent):
	"""
		* Please read learningAgents.py before reading this.*

		An AsynchronousValueIterationAgent takes a Markov decision process
		(see mdp.py) on initialization and runs cyclic value iteration
		for a given number of iterations using the supplied
		discount factor.
	"""
	def __init__(self, mdp, discount = 0.9, iterations = 1000):
		"""
		  Your cyclic value iteration agent should take an mdp on
		  construction, run the indicated number of iterations,
		  and then act according to the resulting policy. Each iteration
		  updates the value of only one state, which cycles through
		  the states list. If the chosen state is terminal, nothing
		  happens in that iteration.

		  Some useful mdp methods you will use:
			  mdp.getStates()
			  mdp.getPossibleActions(state)
			  mdp.getTransitionStatesAndProbs(state, action)
			  mdp.getReward(state)
			  mdp.isTerminal(state)
		"""
		ValueIterationAgent.__init__(self, mdp, discount, iterations)

	def runValueIteration(self):
		
		
		k = self.iterations
		
		#Updates values K times
		while k > 0:
			for stateX in self.mdp.getStates():

				allSums = []
				
				#Get Q values for all the actions
				for actionX in self.mdp.getPossibleActions(stateX):
					S_T_pairs = self.mdp.getTransitionStatesAndProbs(stateX, actionX)
					Sum = 0.0
					for nextStateX, T_x  in S_T_pairs:
						R_x = self.mdp.getReward(stateX, actionX, nextStateX)
						Sum += T_x * (R_x + self.discount * self.values[nextStateX])
					allSums.append(Sum)

					
				if allSums:
					self.values[stateX] = max(allSums)
				else:
					#Terminal state
					self.values[stateX] = 0
				
				k = k - 1
				
				if k == 0:
					break

class PrioritizedSweepingValueIterationAgent(AsynchronousValueIterationAgent):
	"""
		* Please read learningAgents.py before reading this.*

		A PrioritizedSweepingValueIterationAgent takes a Markov decision process
		(see mdp.py) on initialization and runs prioritized sweeping value iteration
		for a given number of iterations using the supplied parameters.
	"""
	def __init__(self, mdp, discount = 0.9, iterations = 100, theta = 1e-5):
		"""
		  Your prioritized sweeping value iteration agent should take an mdp on
		  construction, run the indicated number of iterations,
		  and then act according to the resulting policy.
		"""
		self.theta = theta
		ValueIterationAgent.__init__(self, mdp, discount, iterations)

	def runValueIteration(self):
	
		# This function returns the Max Q value
		def returnValOfState(stateX):
			Q_val = 0
			Max_Q_val = float('-inf')
			for actionX in self.mdp.getPossibleActions(stateX):
				Q_val = self.computeQValueFromValues(stateX, actionX)
				
				if Max_Q_val < Q_val:
					Max_Q_val = Q_val
			
			return Max_Q_val
		
		predecessor_dict = {}
		
		for stateX in self.mdp.getStates():
				predecessor_dict[stateX] = set()
		
		for stateX in self.mdp.getStates():
			if not self.mdp.isTerminal(stateX):
				for actionX in self.mdp.getPossibleActions(stateX):
					S_T_pairs = self.mdp.getTransitionStatesAndProbs(stateX, actionX)
					for stateNext, prob in S_T_pairs:
						predecessor_dict[stateNext].add(stateX)
						
					
		PriQue = util.PriorityQueue()
		
		for stateX in self.mdp.getStates():
		
			if not self.mdp.isTerminal(stateX):
				ValX = returnValOfState(stateX)
				diff = self.values[stateX] - ValX
							
				if diff < 0:
					diff = -diff
					
				PriQue.update(stateX, -diff)
			
		for k in range(self.iterations):
			
			if PriQue.isEmpty():
				return
				
			else:
				stateX = PriQue.pop()
				
				
				if not self.mdp.isTerminal(stateX):
					ValX = returnValOfState(stateX)
					self.values[stateX] = ValX
				

				for preX in predecessor_dict[stateX]:
					if not self.mdp.isTerminal(preX): 
						ValX = returnValOfState(preX)
						diff = self.values[preX] - ValX
						
						if diff < 0:
							diff = -diff

						if diff > self.theta:
							PriQue.update(preX, -diff)
						
				
				
					
			

