# myAgents.py
# ---------------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
#
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).

from game import Agent
from searchProblems import PositionSearchProblem

import util
import time
import search

"""
IMPORTANT
`agent` defines which agent you will use. By default, it is set to ClosestDotAgent,
but when you're ready to test your own agent, replace it with MyAgent
"""
def createAgents(num_pacmen, agent='MyAgent'):
	return [eval(agent)(index=i) for i in range(num_pacmen)]

class MyAgent(Agent):
	"""
	Implementation of your agent.
	
	Guru Sarath Thangamani
	UIN: 829009551
	
	"""
	
	pacPlans = [] #Plans of all pacman
	NumPacs = 0 #Total Number of pacmans
	AllDots = [] #All foods list
	pacStartState = [] #Current postions of all pacmans
	FirstExecution = True #First execution flag
	
	# Simple custom problem class to run this pacman game problem
	class MySearchProblem(PositionSearchProblem):
	
		def __init__(self, gameState, agentIndex):
			self.food = gameState.getFood()
			self.walls = gameState.getWalls()
			self.startState = gameState.getPacmanPosition(agentIndex)
			self.costFn = lambda x: 1
			self._visited, self._visitedlist, self._expanded = {}, [], 0 # DO NOT CHANGE

	def getAction(self, state):
		"""
		Returns the next action the agent will take
		"""
		if MyAgent.FirstExecution:
			MyAgent.NumPacs = state.getNumPacmanAgents() #Get the number of pacmans in this game
			
			# Initialize static lists
			for i in range(MyAgent.NumPacs):
				MyAgent.pacPlans.append([])
				MyAgent.pacGoals.append([])
				MyAgent.pacStartState.append(0)
				MyAgent.pacStartState[i] = state.getPacmanPosition(i)
			#Create a search problem to search
			problem = MyAgent.MySearchProblem(state, self.index)
			MyAgent.AllDots = state.getFood().asList()[:]
			self.Plan_PacMan_All_Greedy_2(problem) # Create a plan for pacmans
			MyAgent.FirstExecution = False #Deactivate first execution
		
		if MyAgent.pacPlans[self.index]:
			# If the pacman already has a plan 
			# then get the action from the plan
			ActionToDoNext = MyAgent.pacPlans[self.index][0]
			MyAgent.pacPlans[self.index].remove(ActionToDoNext)
		else:
			#If the pacman does not have a plan
			#Then create a new single plan only for that pacman
			problem = MyAgent.MySearchProblem(state, self.index)
			MyAgent.AllDots = state.getFood().asList()[:]
			
			for i in range(MyAgent.NumPacs):
				MyAgent.pacStartState[i] = state.getPacmanPosition(i)
				
			self.Plan_1_PacMan_Full(problem, self.index)
			ActionToDoNext = MyAgent.pacPlans[self.index][0]
			MyAgent.pacPlans[self.index].remove(ActionToDoNext)
			#ActionToDoNext = 'Stop'
			
		return ActionToDoNext

	#This function creates plan for all pacmans
	#This function is run only once
	def Plan_PacMan_All_Greedy_2(self, problem):
		
		pacman_i = 0 #Index to iterate through all pacmans
		
		# Create a plan till all the food is eaten
		while(MyAgent.AllDots):
			
			startState = MyAgent.pacStartState[pacman_i]
			GoalFound = False
			current_state = None
			openList = util.Queue()
			
			visitedSet = set()
			CameFrom = {startState: None}
			SolutionActions_Sequence = []
			SolutionState_Sequence = []
			
			openList.push(startState)

			
			while openList:

				current_state = openList.pop()
				visitedSet.add(current_state)
				
				#If the current state is a food then it is a goal
				if current_state in MyAgent.AllDots:
					GoalFound = True
					GoalState = current_state
					break
				
				NextStates = problem.getSuccessors(current_state)
				
				for StateX, ActionX, CostX in NextStates:
					if StateX not in visitedSet and StateX not in openList.list:
						openList.push(StateX)
						CameFrom[StateX] = (current_state, ActionX)

			
			#Reconstruct path from the current goal
			while current_state != startState:
				SolutionState_Sequence.append(CameFrom[current_state][0])
				SolutionActions_Sequence.append(CameFrom[current_state][1])
				current_state = CameFrom[current_state][0]
			
			# Clean Up and Solution append
			
			# Actions to reach a particular food
			SolutionActions_Sequence = SolutionActions_Sequence[::-1]
			#Add the new actions to the master plan list of the pacman
			MyAgent.pacPlans[pacman_i].extend(SolutionActions_Sequence)
			#Current goal state becomes the start state from next search plan
			startState = GoalState
			#Remove the food from dots
			MyAgent.AllDots.remove(startState)
			#Current goal state becomes the start state from next search plan
			MyAgent.pacStartState[pacman_i] = GoalState
			
			#Plan the actions for next pacman
			if pacman_i < MyAgent.NumPacs - 1:
				pacman_i += 1
			else:
				pacman_i = 0

	#This function is called when a pacman has no more actions left in its plan
	#This function creates plan only for one pacman (pacman_i)
	def Plan_1_PacMan_Full(self, problem, pacman_i):
		
		#Plan until no dot is present
		while(MyAgent.AllDots):
		
			startState = MyAgent.pacStartState[pacman_i]
			GoalFound = False
			current_state = None
			openList = util.Queue()
			visitedSet = set()
			CameFrom = {startState: None}
			StepCountDict = {startState: 0}
			SolutionActions_Sequence = []
			SolutionState_Sequence = []
			openList.push(startState)

			
			while openList:

				current_state = openList.pop()
				current_step_count = StepCountDict[current_state]
				visitedSet.add(current_state)
				
				if current_state in MyAgent.AllDots:
					GoalFound = True
					GoalState = current_state
					break
				
				NextStates = problem.getSuccessors(current_state)
				
				for StateX, ActionX, CostX in NextStates:
					
					if StateX not in visitedSet and StateX not in openList.list:
						openList.push(StateX)
						CameFrom[StateX] = (current_state, ActionX)
						StepCountDict[StateX] = current_step_count + 1
						
					if StateX in visitedSet:
						if StepCountDict[StateX] > current_step_count:
							CameFrom[StateX] = (current_state, ActionX)
							StepCountDict[StateX] = current_step_count + 1
			
			#Reconstruct path
			while current_state != startState:
				SolutionState_Sequence.append(CameFrom[current_state][0])
				SolutionActions_Sequence.append(CameFrom[current_state][1])
				current_state = CameFrom[current_state][0]
			
			# Clean Up and Solution append
			
			
			SolutionActions_Sequence = SolutionActions_Sequence[::-1]
			
			#Add the plan to the master plan list
			MyAgent.pacPlans[pacman_i].extend(SolutionActions_Sequence)
			
			startState = GoalState
			MyAgent.AllDots.remove(startState)
			MyAgent.pacStartState[pacman_i] = GoalState
				

		
	def initialize(self):
		"""
		Intialize anything you want to here. This function is called
		when the agent is first created. If you don't need to use it, then
		leave it blank
		"""
		#Initialize all static variables
		MyAgent.pacGoals = []
		MyAgent.pacPlans = []
		MyAgent.NumPacs = 0
		MyAgent.AllDots = []
		MyAgent.FirstExecution = True
		pass

"""
Put any other SearchProblems or search methods below. You may also import classes/methods in
search.py and searchProblems.py. (ClosestDotAgent as an example below)
"""

class ClosestDotAgent(Agent):

	def findPathToClosestDot(self, gameState):
		"""
		Returns a path (a list of actions) to the closest dot, starting from
		gameState.
		"""
		# Here are some useful elements of the startState
		startPosition = gameState.getPacmanPosition(self.index)
		food = gameState.getFood()
		walls = gameState.getWalls()
		problem = AnyFoodSearchProblem(gameState, self.index)
		
		currentPosition = None
		visitedSet = set()
		OpenList = util.PriorityQueue()
		OpenList.push(startPosition, 0)
		cameFrom = dict()
		cameFrom[startPosition] = (None,None)
		SolutionActions_Sequence = []
		
		# Greedy search loop
		
		while not OpenList.isEmpty():
			
			currentPosition = OpenList.pop() # pop the least cost element
			nextStates = problem.getSuccessors(currentPosition)
			visitedSet.add(currentPosition)
			
			#check if current state is a goal
			if problem.isGoalState(currentPosition):
				break
				
			for PosX, ActionX, CostX in nextStates:
				
				if not PosX in visitedSet:
					OpenList.push(PosX, CostX)
					cameFrom[PosX] = (currentPosition, ActionX)
					
		while currentPosition != startPosition:
			SolutionActions_Sequence.append(cameFrom[currentPosition][1])
			currentPosition = cameFrom[currentPosition][0]
			
		#print(goalPosition, SolutionActions_Sequence[::-1])
		return SolutionActions_Sequence[::-1]

	def getAction(self, state):
		return self.findPathToClosestDot(state)[0]

class AnyFoodSearchProblem(PositionSearchProblem):
	"""
	A search problem for finding a path to any food.

	This search problem is just like the PositionSearchProblem, but has a
	different goal test, which you need to fill in below.  The state space and
	successor function do not need to be changed.

	The class definition above, AnyFoodSearchProblem(PositionSearchProblem),
	inherits the methods of the PositionSearchProblem.

	You can use this search problem to help you fill in the findPathToClosestDot
	method.
	"""

	def __init__(self, gameState, agentIndex):
		"Stores information from the gameState.  You don't need to change this."
		# Store the food for later reference
		self.food = gameState.getFood()

		# Store info for the PositionSearchProblem (no need to change this)
		self.walls = gameState.getWalls()
		self.startState = gameState.getPacmanPosition(agentIndex)
		self.costFn = lambda x: 1
		self._visited, self._visitedlist, self._expanded = {}, [], 0 # DO NOT CHANGE

	def isGoalState(self, state):
		"""
		The state is Pacman's position. Fill this in with a goal test that will
		complete the problem definition.
		"""
		# FROM PREVIOUS PROJECT

		x,y = state
		distanceToFood = []
		
		# Calculate distance to all dots
		for x_food, y_food in self.food.asList():
			distanceToFood.append( ( (x - x_food)**2 + (y - y_food)**2 )**0.5 )
		
		# Get the closest dot location
		indexOfMinElement = distanceToFood.index(min(distanceToFood))
		goalPosition = self.food.asList()[indexOfMinElement]
		
		#if pacman is in closest dot -> goal reached
		if goalPosition == state:
			return True
		else:
			return False

