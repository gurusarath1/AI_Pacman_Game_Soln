# myAgents.py
# ---------------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
#
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).

from game import Agent
from searchProblems import PositionSearchProblem

import util
import time
import search
import random

"""
IMPORTANT
`agent` defines which agent you will use. By default, it is set to ClosestDotAgent,
but when you're ready to test your own agent, replace it with MyAgent
"""
def createAgents(num_pacmen, agent='MyAgent'):
	return [eval(agent)(index=i) for i in range(num_pacmen)]

class MyAgent(Agent):
	"""
	Implementation of your agent.
	"""
	
	pacGoals = []
	pacPlans = []
	NumPacs = 0
	AllDots = []

	class MySearchProblem(PositionSearchProblem):
	
		def __init__(self, gameState, goalPos, agentIndex):
			"Stores information from the gameState.  You don't need to change this."
			# Store the food for later reference
			self.food = gameState.getFood()
			# Store info for the PositionSearchProblem (no need to change this)
			self.walls = gameState.getWalls()
			self.startState = gameState.getPacmanPosition(agentIndex)
			self.costFn = lambda x: 1
			self._visited, self._visitedlist, self._expanded = {}, [], 0 # DO NOT CHANGE
			self.goalPos = goalPos
			
		def isGoalState(self, state):
			
			if state == self.goalPos:
				
				return True
			else:
				return False
		
	def getAction(self, state):
		"""
		Returns the next action the agent will take
		"""
		
		MyAgent.AllDots = state.getFood().asList()
		CurrentPosition = state.getPacmanPosition(self.index)
	
		# Runs once
		if MyAgent.pacGoals == []:
			MyAgent.NumPacs = state.getNumPacmanAgents()
			#print(state.getNumPacmanAgents())
			for i in range(MyAgent.NumPacs):
				MyAgent.pacPlans.append([])
				MyAgent.pacGoals.append([])
			
		if MyAgent.pacPlans[self.index] == [] or MyAgent.pacGoals[self.index] not in MyAgent.AllDots:
			
			self.Get_this_PacmanAGoal(CurrentPosition)
			
			problem = self.MySearchProblem(state, MyAgent.pacGoals[self.index], self.index)
			self.actionToDo = self.Plan_PacMan(problem)
			MyAgent.pacPlans[self.index] = self.actionToDo

		
		Act = MyAgent.pacPlans[self.index][0]
		MyAgent.pacPlans[self.index].remove(Act)
			
		return Act
	
	def Get_this_PacmanAGoal(self, CurrentPosition):
		minDist = float("inf")
		minDist_dot = None
		minDist_dot_2 = None
			
		for dotX in MyAgent.AllDots:
			dist = util.manhattanDistance(dotX, CurrentPosition)
				
			if minDist > dist and dotX not in MyAgent.pacGoals:
				minDist = dist
				minDist_dot = dotX
			elif minDist > dist:
				minDist_dot_2 = dotX

			if minDist_dot:
				MyAgent.pacGoals[self.index] = minDist_dot
			elif minDist_dot_2:
				MyAgent.pacGoals[self.index] = minDist_dot_2
			elif MyAgent.AllDots:
				MyAgent.pacGoals[self.index] = MyAgent.AllDots[0]
				
	def Get_this_PacmanAGoal_2(self, CurrentPosition):
			
		r = random.choice(MyAgent.AllDots)
		
		i = 0
		while r in MyAgent.pacGoals:
			if i > len(MyAgent.pacGoals):
				break
			r = random.choice(MyAgent.AllDots)
			i += 1
			
		MyAgent.pacGoals[self.index] = r
		
	def Plan_PacMan(self, problem):
		
		startState = problem.getStartState()
		GoalState = None
		
		current_state = None
		openList = util.PriorityQueue()
		openList_2 = []
		visitedSet = set()
		CameFrom = {startState: None}
		SolutionActions_Sequence = []
		SolutionState_Sequence = []
		
		openList.push(startState, 0)
		
		while openList:

			current_state = openList.pop()
			visitedSet.add(current_state)
			
			if problem.isGoalState(current_state):
				GoalState = current_state
				break
			
			NextStates = problem.getSuccessors(current_state)
			
			for StateX, ActionX, CostX in NextStates:
				
				if StateX not in visitedSet and StateX not in openList_2:
				
					openList.push(StateX, self.h(StateX, problem.goalPos))
					openList_2.append(StateX)
					CameFrom[StateX] = (current_state, ActionX)
			
			

		while current_state != startState:
			SolutionState_Sequence.append(CameFrom[current_state][0])
			SolutionActions_Sequence.append(CameFrom[current_state][1])
			current_state = CameFrom[current_state][0]
				
		SolutionActions_Sequence = SolutionActions_Sequence[::-1]
		
		return SolutionActions_Sequence
			
		
	def h(self, Pos, goalPos):
		return util.manhattanDistance(Pos, goalPos)
		#return 0
		
		
	def initialize(self):
		"""
		Intialize anything you want to here. This function is called
		when the agent is first created. If you don't need to use it, then
		leave it blank
		"""
		MyAgent.pacGoals = []
		MyAgent.pacPlans = []
		MyAgent.NumPacs = 0
		MyAgent.AllDots = []
		pass

"""
Put any other SearchProblems or search methods below. You may also import classes/methods in
search.py and searchProblems.py. (ClosestDotAgent as an example below)
"""

class ClosestDotAgent(Agent):

	def findPathToClosestDot(self, gameState):
		"""
		Returns a path (a list of actions) to the closest dot, starting from
		gameState.
		"""
		# Here are some useful elements of the startState
		startPosition = gameState.getPacmanPosition(self.index)
		food = gameState.getFood()
		walls = gameState.getWalls()
		problem = AnyFoodSearchProblem(gameState, self.index)
		
		currentPosition = None
		visitedSet = set()
		OpenList = util.PriorityQueue()
		OpenList.push(startPosition, 0)
		cameFrom = dict()
		cameFrom[startPosition] = (None,None)
		SolutionActions_Sequence = []
		
		# Greedy search loop
		
		while not OpenList.isEmpty():
			
			currentPosition = OpenList.pop() # pop the least cost element
			nextStates = problem.getSuccessors(currentPosition)
			visitedSet.add(currentPosition)
			
			#check if current state is a goal
			if problem.isGoalState(currentPosition):
				break
				
			for PosX, ActionX, CostX in nextStates:
				
				if not PosX in visitedSet:
					OpenList.push(PosX, CostX)
					cameFrom[PosX] = (currentPosition, ActionX)
					
		while currentPosition != startPosition:
			SolutionActions_Sequence.append(cameFrom[currentPosition][1])
			currentPosition = cameFrom[currentPosition][0]
			
		#print(goalPosition, SolutionActions_Sequence[::-1])
		return SolutionActions_Sequence[::-1]

	def getAction(self, state):
		return self.findPathToClosestDot(state)[0]

class AnyFoodSearchProblem(PositionSearchProblem):
	"""
	A search problem for finding a path to any food.

	This search problem is just like the PositionSearchProblem, but has a
	different goal test, which you need to fill in below.  The state space and
	successor function do not need to be changed.

	The class definition above, AnyFoodSearchProblem(PositionSearchProblem),
	inherits the methods of the PositionSearchProblem.

	You can use this search problem to help you fill in the findPathToClosestDot
	method.
	"""

	def __init__(self, gameState, agentIndex):
		"Stores information from the gameState.  You don't need to change this."
		# Store the food for later reference
		self.food = gameState.getFood()

		# Store info for the PositionSearchProblem (no need to change this)
		self.walls = gameState.getWalls()
		self.startState = gameState.getPacmanPosition(agentIndex)
		self.costFn = lambda x: 1
		self._visited, self._visitedlist, self._expanded = {}, [], 0 # DO NOT CHANGE

	def isGoalState(self, state):
		"""
		The state is Pacman's position. Fill this in with a goal test that will
		complete the problem definition.
		"""
		# FROM PREVIOUS PROJECT

		x,y = state
		distanceToFood = []
		
		# Calculate distance to all dots
		for x_food, y_food in self.food.asList():
			distanceToFood.append( ( (x - x_food)**2 + (y - y_food)**2 )**0.5 )
		
		# Get the closest dot location
		indexOfMinElement = distanceToFood.index(min(distanceToFood))
		goalPosition = self.food.asList()[indexOfMinElement]
		
		#if pacman is in closest dot -> goal reached
		if goalPosition == state:
			return True
		else:
			return False

