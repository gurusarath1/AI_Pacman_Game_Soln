# myTeam.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


from captureAgents import CaptureAgent
import random, time, util
from game import Directions
import game

#################
# Team creation #
#################

def createTeam(firstIndex, secondIndex, isRed,
			   first = 'MyPac', second = 'MyGhost'):
	"""
	This function should return a list of two agents that will form the
	team, initialized using firstIndex and secondIndex as their agent
	index numbers.  isRed is True if the red team is being created, and
	will be False if the blue team is being created.

	As a potentially helpful development aid, this function can take
	additional string-valued keyword arguments ("first" and "second" are
	such arguments in the case of this function), which will come from
	the --redOpts and --blueOpts command-line arguments to capture.py.
	For the nightly contest, however, your team will be created without
	any extra arguments, so you should make sure that the default
	behavior is what you want for the nightly contest.
	"""

	# The following line is an example only; feel free to change it.
	return [eval(first)(firstIndex), eval(second)(secondIndex)]

##########
# Agents #
##########

class MyPac(CaptureAgent):
	"""
	A Dummy agent to serve as an example of the necessary agent structure.
	You should look at baselineTeam.py for more details about how to
	create an agent as this is the bare minimum.
	"""

	def registerInitialState(self, gameState):
		"""
		This method handles the initial setup of the
		agent to populate useful fields (such as what team
		we're on).

		A distanceCalculator instance caches the maze distances
		between each pair of positions, so your agents can use:
		self.distancer.getDistance(p1, p2)

		IMPORTANT: This method may run for at most 15 seconds.
		"""

		'''
		Make sure you do not delete the following line. If you would like to
		use Manhattan distances instead of maze distances in order to save
		on initialization time, please take a look at
		CaptureAgent.registerInitialState in captureAgents.py.
		'''
		CaptureAgent.registerInitialState(self, gameState)
		self.depth = 2
		self.my_team = CaptureAgent.getTeam(self,gameState)
		self.my_pac = self.my_team[0]
		self.my_ghost = self.my_team[1]
		self.my_pac_start_pos = gameState.getAgentPosition(self.my_pac)
		self.my_ghost_start_pos = gameState.getAgentPosition(self.my_ghost)
		self.opponents = self.getOpponents(gameState)
		self.opp1_start_pos = gameState.getAgentPosition(self.opponents[0])
		self.opp2_start_pos = gameState.getAgentPosition(self.opponents[1])
		self.num_food_eaten = 0

		self.walls = gameState.getWalls().asList()

		self.border = self.my_end()




		'''
		Your initialization code goes here, if you need any.
		'''
	def my_end(self): 
		x_list_max = max([self.my_pac_start_pos[0],self.my_ghost_start_pos[0],self.opp1_start_pos[0],self.opp2_start_pos[0]])
		x_list_min = min([self.my_pac_start_pos[0],self.my_ghost_start_pos[0],self.opp1_start_pos[0],self.opp2_start_pos[0]])
		y_list_max = max([self.my_pac_start_pos[1],self.my_ghost_start_pos[1],self.opp1_start_pos[1],self.opp2_start_pos[1]])
		y_list_min = min([self.my_pac_start_pos[1],self.my_ghost_start_pos[1],self.opp1_start_pos[1],self.opp2_start_pos[1]])
		border = []
		self.x_mid = int((x_list_max)/2)

		if self.red:
			for i in range(y_list_max+1):
				if (self.x_mid,i) not in self.walls:
					border.append((self.x_mid,i))
		else:
			for i in range(y_list_max+1):
				if (self.x_mid+1,i) not in self.walls:
					border.append((self.x_mid+1,i))
		return border

	def chooseAction(self, gameState):
		"""
		Picks among actions randomly.
		"""

		self.opp1_pos = gameState.getAgentPosition(self.opponents[0])
		self.opp2_pos = gameState.getAgentPosition(self.opponents[1])
		self.capsules = gameState.getBlueCapsules()
		self.my_pac_pos = gameState.getAgentPosition(self.my_pac)
		self.my_ghost_pos = gameState.getAgentPosition(self.my_ghost)
		self.distance_to_opp1 = self.distancer.getDistance(self.my_pac_pos, self.opp1_pos)
		self.distance_to_opp2 = self.distancer.getDistance(self.my_pac_pos, self.opp2_pos)
		self.distance_my_ghost_my_pac = self.distancer.getDistance(self.my_pac_pos, self.my_ghost_pos)

		if self.red:
			is_score = gameState.getScore() > 0
			if self.opp1_pos[0] < self.x_mid:
				self.opp_off_agent = self.opponents[0]
				self.opp_def_agent = self.opponents[1]
			else:
				self.opp_off_agent = self.opponents[1]
				self.opp_def_agent = self.opponents[0]
		else:
			is_score = gameState.getScore() < 0
			if self.opp1_pos[0] > self.x_mid:
				self.opp_off_agent = self.opponents[0]
				self.opp_def_agent = self.opponents[1]
			else:
				self.opp_off_agent = self.opponents[1]
				self.opp_def_agent = self.opponents[0]

		self.opp_off_agent_pos = gameState.getAgentPosition(self.opp_off_agent)
		self.opp_def_agent_pos = gameState.getAgentPosition(self.opp_def_agent)

		self.distance_to_off_agent = self.distancer.getDistance(self.my_pac_pos, self.opp_off_agent_pos)
		self.distance_to_def_agent = self.distancer.getDistance(self.my_pac_pos, self.opp_def_agent_pos)


		actions = gameState.getLegalActions(self.my_pac)
		#print(gameState.getScore())

		'''
		You should change this in your own agent.
		'''	
		all_food = self.getFood(gameState).asList()

		if self.red:
			is_opp_here = (self.opp_off_agent_pos[0] <= self.x_mid) or (self.opp_def_agent_pos[0] <= self.x_mid)
		else:
			is_opp_here = (self.opp_off_agent_pos[0] >= self.x_mid) or (self.opp_def_agent_pos[0] >= self.x_mid)



		if len(all_food) > 0 and self.distance_to_def_agent > 5 and self.distance_to_off_agent > 5:
			min_dist_values = []
			for a in actions:
				succ = gameState.generateSuccessor(self.my_pac,a)
				pos = succ.getAgentState(self.my_pac).getPosition()
				all_dist = []
				for food in all_food:
					all_dist.append(self.distancer.getDistance(food, pos))
				score = min(all_dist)
				min_dist_values.append(score)
				action_to_ret = actions[min_dist_values.index(min(min_dist_values))]
				succ_1 = gameState.generateSuccessor(self.my_pac,a)
				pos_1 = succ.getAgentState(self.my_pac).getPosition()
				if pos_1 in all_food:
					self.num_food_eaten += 1
					#print("food=",self.num_food_eaten)
			return action_to_ret
		elif is_opp_here and is_score:
			all_dist = []
			for a in actions:
				succ = gameState.generateSuccessor(self.my_pac,a)
				pos = succ.getAgentState(self.my_pac).getPosition()
				self.opp_off_agent_pos = gameState.getAgentPosition(self.opp_off_agent)
				all_dist.append(self.distancer.getDistance(pos,self.opp_off_agent_pos))
			return actions[all_dist.index(min(all_dist))]
		else:
			min_dist_values = []
			for a in actions:
				succ = gameState.generateSuccessor(self.my_pac,a)
				pos = succ.getAgentState(self.my_pac).getPosition()
				all_dist = []
				for border in self.border:
					all_dist.append(self.distancer.getDistance(border, pos))
				score = min(all_dist)
				min_dist_values.append(score)
				if self.my_pac_pos in self.border:
					#print("in_border")
					self.num_food_eaten = 0
			return actions[min_dist_values.index(min(min_dist_values))]

class MyGhost(CaptureAgent):
	"""
	A Dummy agent to serve as an example of the necessary agent structure.
	You should look at baselineTeam.py for more details about how to
	create an agent as this is the bare minimum.
	"""

	def registerInitialState(self, gameState):
		"""
		This method handles the initial setup of the
		agent to populate useful fields (such as what team
		we're on).

		A distanceCalculator instance caches the maze distances
		between each pair of positions, so your agents can use:
		self.distancer.getDistance(p1, p2)

		IMPORTANT: This method may run for at most 15 seconds.
		"""

		'''
		Make sure you do not delete the following line. If you would like to
		use Manhattan distances instead of maze distances in order to save
		on initialization time, please take a look at
		CaptureAgent.registerInitialState in captureAgents.py.
		'''
		CaptureAgent.registerInitialState(self, gameState)

		'''
		Your initialization code goes here, if you need any.
		'''
		self.depth = 2
		self.my_team = CaptureAgent.getTeam(self,gameState)
		self.my_pac = self.my_team[0]
		self.my_ghost = self.my_team[1]
		self.my_pac_start_pos = gameState.getAgentPosition(self.my_pac)
		self.my_ghost_start_pos = gameState.getAgentPosition(self.my_ghost)
		self.num_food_eaten = 0
		self.opponents = self.getOpponents(gameState)
		self.opp1_start_pos = gameState.getAgentPosition(self.opponents[0])
		self.opp2_start_pos = gameState.getAgentPosition(self.opponents[1])
		self.num_food_eaten = 0
		self.walls = gameState.getWalls().asList()
		self.border = self.my_end()
		self.enemy_food = self.getFood(gameState).asList()
		self.num_food = len(self.enemy_food)

		'''
		Your initialization code goes here, if you need any.
		'''
	def my_end(self): 
		x_list_max = max([self.my_pac_start_pos[0],self.my_ghost_start_pos[0],self.opp1_start_pos[0],self.opp2_start_pos[0]])
		x_list_min = min([self.my_pac_start_pos[0],self.my_ghost_start_pos[0],self.opp1_start_pos[0],self.opp2_start_pos[0]])
		y_list_max = max([self.my_pac_start_pos[1],self.my_ghost_start_pos[1],self.opp1_start_pos[1],self.opp2_start_pos[1]])
		y_list_min = min([self.my_pac_start_pos[1],self.my_ghost_start_pos[1],self.opp1_start_pos[1],self.opp2_start_pos[1]])
		border = []
		self.x_mid = int((x_list_max)/2)

		if self.red:
			for i in range(y_list_max+1):
				if (self.x_mid,i) not in self.walls:
					border.append((self.x_mid,i))
		else:
			for i in range(y_list_max+1):
				if (self.x_mid+1,i) not in self.walls:
					border.append((self.x_mid+1,i))
		return border


	def chooseAction(self, gameState):
		"""
		Picks among actions randomly.
		"""


		actions = gameState.getLegalActions(self.my_ghost)

		'''
		You should change this in your own agent.
		'''		
		
		all_food = self.getFood(gameState).asList()
		all_food_ours = self.getFoodYouAreDefending(gameState).asList()
		self.opponents = self.getOpponents(gameState)
		self.opponents = self.getOpponents(gameState)
		self.opp1_pos = gameState.getAgentPosition(self.opponents[0])
		self.opp2_pos = gameState.getAgentPosition(self.opponents[1])
		self.capsules = gameState.getBlueCapsules()
		self.my_pac_pos = gameState.getAgentPosition(self.my_pac)
		self.my_ghost_pos = gameState.getAgentPosition(self.my_ghost)
		self.distance_to_opp1 = self.distancer.getDistance(self.my_pac_pos, self.opp1_pos)
		self.distance_to_opp2 = self.distancer.getDistance(self.my_pac_pos, self.opp2_pos)
		self.distance_my_ghost_my_pac = self.distancer.getDistance(self.my_pac_pos, self.my_ghost_pos)

		if self.red:

			is_score = gameState.getScore() > 0
			if self.opp1_pos[0] < self.x_mid:
				self.opp_off_agent = self.opponents[0]
				self.opp_def_agent = self.opponents[1]
			else:
				self.opp_off_agent = self.opponents[1]
				self.opp_def_agent = self.opponents[0]
		else:
			
			is_score = gameState.getScore() < 0
			if self.opp1_pos[0] > self.x_mid:
				self.opp_off_agent = self.opponents[0]
				self.opp_def_agent = self.opponents[1]
			else:
				self.opp_off_agent = self.opponents[1]
				self.opp_def_agent = self.opponents[0]

		self.opp_off_agent_pos = gameState.getAgentPosition(self.opp_off_agent)
		self.opp_def_agent_pos = gameState.getAgentPosition(self.opp_def_agent)

		self.distance_to_off_agent = self.distancer.getDistance(self.my_ghost_pos, self.opp_off_agent_pos)
		self.distance_to_def_agent = self.distancer.getDistance(self.my_ghost_pos, self.opp_def_agent_pos)

		if self.red:
			is_opp_here = (self.opp_off_agent_pos[0] <= self.x_mid) or (self.opp_def_agent_pos[0] <= self.x_mid)
		else:
			is_opp_here = (self.opp_off_agent_pos[0] >= self.x_mid) or (self.opp_def_agent_pos[0] >= self.x_mid)
			


		if len(all_food_ours) < (self.num_food + 1) and is_opp_here:
			all_dist = []
			for a in actions:
				succ = gameState.generateSuccessor(self.my_ghost,a)
				pos = succ.getAgentState(self.my_ghost).getPosition()
				self.opp_off_agent_pos = gameState.getAgentPosition(self.opp_off_agent)
				all_dist.append(self.distancer.getDistance(pos,self.opp_off_agent_pos))
			return actions[all_dist.index(min(all_dist))]
		elif self.distance_my_ghost_my_pac < 5 and not is_opp_here and (self.distance_to_def_agent > 5 or self.distance_to_off_agent > 5) and self.my_pac_pos in self.border:
			#print("Going to eat food")
			min_dist_values = []
			for a in actions:
				succ = gameState.generateSuccessor(self.my_ghost,a)
				pos = succ.getAgentState(self.my_ghost).getPosition()
				all_dist = []
				for food in all_food:
					all_dist.append(self.distancer.getDistance(food, pos))
				score = min(all_dist)
				min_dist_values.append(score)
				action_to_ret = actions[min_dist_values.index(min(min_dist_values))]
				succ_1 = gameState.generateSuccessor(self.my_ghost,a)
				pos_1 = succ.getAgentState(self.my_ghost).getPosition()
				if pos_1 in all_food:
					self.num_food_eaten += 1
					#print("food=",self.num_food_eaten)
			return action_to_ret
		else:
			min_dist_values = []
			for a in actions:
				succ = gameState.generateSuccessor(self.my_ghost,a)
				pos = succ.getAgentState(self.my_ghost).getPosition()
				all_dist = []
				for border in self.border:
					all_dist.append(self.distancer.getDistance(border, pos))
				score = min(all_dist)
				min_dist_values.append(score)
				if self.my_ghost_pos in self.border:
					self.num_food_eaten = 0
			return actions[min_dist_values.index(min(min_dist_values))]








