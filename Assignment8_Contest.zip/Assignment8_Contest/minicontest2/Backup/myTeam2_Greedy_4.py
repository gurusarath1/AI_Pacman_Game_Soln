# myTeam.py
# ---------
# Licensing Information:	You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


from captureAgents import CaptureAgent
import random, time, util
from game import Directions
import game

#################
# Team creation #
#################

def createTeam(firstIndex, secondIndex, isRed,
							 first = 'DummyAgent', second = 'DummyAgent'):
	"""
	This function should return a list of two agents that will form the
	team, initialized using firstIndex and secondIndex as their agent
	index numbers.	isRed is True if the red team is being created, and
	will be False if the blue team is being created.

	As a potentially helpful development aid, this function can take
	additional string-valued keyword arguments ("first" and "second" are
	such arguments in the case of this function), which will come from
	the --redOpts and --blueOpts command-line arguments to capture.py.
	For the nightly contest, however, your team will be created without
	any extra arguments, so you should make sure that the default
	behavior is what you want for the nightly contest.
	"""

	# The following line is an example only; feel free to change it.
	return [eval(first)(firstIndex), eval(second)(secondIndex)]

##########
# Agents #
##########

class DummyAgent(CaptureAgent):
	"""
	A Dummy agent to serve as an example of the necessary agent structure.
	You should look at baselineTeam.py for more details about how to
	create an agent as this is the bare minimum.
	"""

	def registerInitialState(self, gameState):
		"""
		This method handles the initial setup of the
		agent to populate useful fields (such as what team
		we're on).

		A distanceCalculator instance caches the maze distances
		between each pair of positions, so your agents can use:
		self.distancer.getDistance(p1, p2)

		IMPORTANT: This method may run for at most 15 seconds.
		"""

		'''
		Make sure you do not delete the following line. If you would like to
		use Manhattan distances instead of maze distances in order to save
		on initialization time, please take a look at
		CaptureAgent.registerInitialState in captureAgents.py.
		'''
		CaptureAgent.registerInitialState(self, gameState)


		self.team = self.getTeam(gameState)
		self.startPos = gameState.getAgentPosition(self.index)
		self.opponent = self.getOpponents(gameState)
		self.foodEaten = 0

		print(self.team)
		print(self.opponent)
		

		'''
		Your initialization code goes here, if you need any.
		'''


	def chooseAction(self, gameState):
		"""
		Picks among actions randomly.
		"""	
		actions = gameState.getLegalActions(self.index)
		'''
		You should change this in your own agent.
		'''
		#print(self.getCurrentObservation())

		if gameState.getAgentPosition(self.index) == self.startPos:
			self.foodEaten = 0



		self.distancer.getMazeDistances()

		if self.index == self.team[0]:

			print(self.foodEaten)

			if self.foodEaten < 2:
				act = self.greedyAgent(gameState)
			else:
				act = self.greedyGoBack(gameState)
		
		else:

			act = random.choice(actions)


		return act


	def greedyGoBack(self, gameState):

		actions = gameState.getLegalActions(self.index)

		minDistAct = None
		minDist = float('inf')

		for actX in actions:

			NextState = gameState.generateSuccessor(self.index, actX)
			pacPosAfterAction = NextState.getAgentPosition(self.index)

			dist = self.getMazeDistance(pacPosAfterAction, self.startPos)

			if dist < minDist:
				minDist = dist
				minDistAct = actX

		return minDistAct



	def greedyAgent(self, gameState):

		
		foodList = self.getFood(gameState).asList()
		pacPosBeforeAct = gameState.getAgentPosition(self.index)
		nearestFood = self.getNearestFood(pacPosBeforeAct, foodList)

		actions = gameState.getLegalActions(self.index)

		minDistAct = None
		minDist = float('inf')

		for actX in actions:

			NextState = gameState.generateSuccessor(self.index, actX)
			pacPosAfterAction = NextState.getAgentPosition(self.index)

			dist = self.getMazeDistance(pacPosAfterAction, nearestFood)

			if dist < minDist:
				minDist = dist
				minDistAct = actX

		NextState = gameState.generateSuccessor(self.index, minDistAct)
		pacPosAfterAction = NextState.getAgentPosition(self.index)

		if pacPosAfterAction in foodList:
			self.foodEaten += 1

		return minDistAct



	def getNearestFood(self, pacPos, FoodList):

		minDist = float('inf')
		MinPos = None

		for foodPosX in FoodList:

			dist = self.getMazeDistance(pacPos, foodPosX)

			if dist < minDist:
				minDist = dist
				MinPos = foodPosX

		return MinPos



	def getaverageDistance(self, currrentPost, AllOtherPosList):

		val = 0

		for pos in AllOtherPosList:
				val += self.getMazeDistance(currrentPost, pos)

		return val / len(AllOtherPosList)

