# myTeam.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


from captureAgents import CaptureAgent
import random, time, util
from game import Directions
import game

#################
# Team creation #
#################

def createTeam(firstIndex, secondIndex, isRed,
			   first = 'MyPac', second = 'MyGhost'):
	"""
	This function should return a list of two agents that will form the
	team, initialized using firstIndex and secondIndex as their agent
	index numbers.  isRed is True if the red team is being created, and
	will be False if the blue team is being created.

	As a potentially helpful development aid, this function can take
	additional string-valued keyword arguments ("first" and "second" are
	such arguments in the case of this function), which will come from
	the --redOpts and --blueOpts command-line arguments to capture.py.
	For the nightly contest, however, your team will be created without
	any extra arguments, so you should make sure that the default
	behavior is what you want for the nightly contest.
	"""

	# The following line is an example only; feel free to change it.
	return [eval(first)(firstIndex), eval(second)(secondIndex)]

##########
# Agents #
##########

class MyPac(CaptureAgent):
	"""
	A Dummy agent to serve as an example of the necessary agent structure.
	You should look at baselineTeam.py for more details about how to
	create an agent as this is the bare minimum.
	"""

	def registerInitialState(self, gameState):
		"""
		This method handles the initial setup of the
		agent to populate useful fields (such as what team
		we're on).

		A distanceCalculator instance caches the maze distances
		between each pair of positions, so your agents can use:
		self.distancer.getDistance(p1, p2)

		IMPORTANT: This method may run for at most 15 seconds.
		"""

		'''
		Make sure you do not delete the following line. If you would like to
		use Manhattan distances instead of maze distances in order to save
		on initialization time, please take a look at
		CaptureAgent.registerInitialState in captureAgents.py.
		'''
		CaptureAgent.registerInitialState(self, gameState)
		self.depth = 2
		self.my_team = CaptureAgent.getTeam(self,gameState)
		self.my_pac = self.my_team[0]
		self.my_ghost = self.my_team[1]
		self.my_pac_start_pos = gameState.getAgentPosition(self.my_pac)
		self.my_ghost_start_pos = gameState.getAgentPosition(self.my_ghost)
		opponents = self.getOpponents(gameState)
		opp1_pos = gameState.getAgentPosition(opponents[0])
		opp2_pos = gameState.getAgentPosition(opponents[1])
		self.num_food_eaten = 0
		x_mid = int(abs(self.my_pac_start_pos[0] - opp1_pos[0])/2)
		y_mid = int(abs(self.my_pac_start_pos[1] - opp1_pos[1])/2)
		self.mid_red = (x_mid+1,y_mid+1)
		


		'''
		Your initialization code goes here, if you need any.
		'''


	def chooseAction(self, gameState):
		"""
		Picks among actions randomly.
		"""
		opponents = self.getOpponents(gameState)
		self.opp1_pos = gameState.getAgentPosition(opponents[0])
		self.opp2_pos = gameState.getAgentPosition(opponents[1])
		self.capsules = gameState.getBlueCapsules()
		self.my_pac_pos = gameState.getAgentPosition(self.my_pac)
		self.my_ghost_pos = gameState.getAgentPosition(self.my_ghost)
		self.distance_to_opp1 = self.distancer.getDistance(self.my_pac_pos, self.opp1_pos)
		self.distance_to_opp2 = self.distancer.getDistance(self.my_pac_pos, self.opp2_pos)
		self.distance_my_ghost_my_pac = self.distancer.getDistance(self.my_pac_pos, self.my_ghost_pos)
		if (self.opp1_pos[0] - self.my_pac_start_pos[0]) < self.mid_red[0]:
			self.opp_off_agent = opponents[0]
			self.opp_def_agent = opponents[1]
		else:
			self.opp_off_agent = opponents[1]
			self.opp_def_agent = opponents[0]
		self.opp_off_agent_pos = gameState.getAgentPosition(self.opp_off_agent)
		self.opp_def_agent_pos = gameState.getAgentPosition(self.opp_def_agent)

		self.distance_to_off_agent = self.distancer.getDistance(self.my_pac_pos, self.opp_off_agent_pos)
		self.distance_to_def_agent = self.distancer.getDistance(self.my_pac_pos, self.opp_def_agent_pos)
		#self.distance_to_capsules = self.distancer.getDistance(self.my_pac_pos,self.capsules[0] )
		'''wall_top = gameState.hasWall(self.my_pac_pos[0], self.my_pac_pos[1]+1)
		wall_down = gameState.hasWall(self.my_pac_pos[0], self.my_pac_pos[0]-1)
		wall_right = gameState.hasWall(self.my_pac_pos[0]+1, self.my_pac_pos[0])
		wall_left = gameState.hasWall(self.my_pac_pos[0]-1, self.my_pac_pos[0])'''


		actions = gameState.getLegalActions(self.my_pac)

		'''
		You should change this in your own agent.
		'''	
		all_food = self.getFood(gameState).asList()
		if len(all_food) > 0 and self.num_food_eaten <= 0 and (self.distance_to_off_agent > 5 and self.distance_to_def_agent > 5):
			#print('Yes')
			min_dist_values = []
			for a in actions:
				succ = gameState.generateSuccessor(self.my_pac,a)
				pos = succ.getAgentState(self.my_pac).getPosition()
				all_dist = []
				for food in all_food:
					all_dist.append(self.distancer.getDistance(food, pos))
				score = min(all_dist)
				min_dist_values.append(score)

			if gameState.generateSuccessor(self.my_pac,actions[min_dist_values.index(min(min_dist_values))]).getAgentState(self.my_pac).getPosition() in all_food:
				self.num_food_eaten += 1
				#print(self.num_food_eaten)
				#print(self.num_food_eaten)

			return actions[min_dist_values.index(min(min_dist_values))]
		else:
			dist_values = []
			for a in actions:
				#print('No')
				succ = gameState.generateSuccessor(self.my_pac,a)
				pos = succ.getAgentState(self.my_pac).getPosition()
				score = self.distancer.getDistance(self.mid_red, pos)
				#if a != 'Stop':
				dist_values.append(score)
				if actions[dist_values.index(min(dist_values))] == 'Stop':
					self.num_food_eaten = 0
				#print(self.num_food_eaten)
				#print(dist_values)
			return actions[dist_values.index(min(dist_values))]


			'''all_food_ours = self.getFoodYouAreDefending(gameState).asList()
			min_dist_values = []
			for a in actions:
				succ = gameState.generateSuccessor(self.my_pac,a)
				pos = succ.getAgentState(self.my_pac).getPosition()
				all_dist = []
					all_dist.append(self.distancer.getDistance(food, pos))
				min_dist_values.append(min(all_dist))
				if min(min_dist_values) > 5:
					self.num_food_eaten = 0
				if actions[min_dist_values.index(min(min_dist_values))] == 'Stop':
					return 

			return actions[min_dist_values.index(min(min_dist_values))]'''



class MyGhost(CaptureAgent):
	"""
	A Dummy agent to serve as an example of the necessary agent structure.
	You should look at baselineTeam.py for more details about how to
	create an agent as this is the bare minimum.
	"""

	def registerInitialState(self, gameState):
		"""
		This method handles the initial setup of the
		agent to populate useful fields (such as what team
		we're on).

		A distanceCalculator instance caches the maze distances
		between each pair of positions, so your agents can use:
		self.distancer.getDistance(p1, p2)

		IMPORTANT: This method may run for at most 15 seconds.
		"""

		'''
		Make sure you do not delete the following line. If you would like to
		use Manhattan distances instead of maze distances in order to save
		on initialization time, please take a look at
		CaptureAgent.registerInitialState in captureAgents.py.
		'''
		CaptureAgent.registerInitialState(self, gameState)

		'''
		Your initialization code goes here, if you need any.
		'''
		self.depth = 2
		self.my_team = CaptureAgent.getTeam(self,gameState)
		self.my_pac = self.my_team[0]
		self.my_ghost = self.my_team[1]
		self.my_pac_start_pos = gameState.getAgentPosition(self.my_pac)
		self.my_ghost_start_pos = gameState.getAgentPosition(self.my_ghost)
		opponents = self.getOpponents(gameState)
		self.opp1_pos = gameState.getAgentPosition(opponents[0])
		self.opp2_pos = gameState.getAgentPosition(opponents[1])
		self.num_food_eaten = 0
		x_mid = int(abs(self.my_pac_start_pos[0] - self.opp1_pos[0])/2)
		y_mid = int(abs(self.my_pac_start_pos[1] - self.opp1_pos[1])/2)
		self.mid_red = (x_mid,y_mid)


	def chooseAction(self, gameState):
		"""
		Picks among actions randomly.
		"""


		actions = gameState.getLegalActions(self.my_ghost)

		'''
		You should change this in your own agent.
		'''		
		
		all_food = self.getFood(gameState).asList()
		all_food_ours = self.getFoodYouAreDefending(gameState).asList()
		opponents = self.getOpponents(gameState)
		opponents = self.getOpponents(gameState)
		self.opp1_pos = gameState.getAgentPosition(opponents[0])
		self.opp2_pos = gameState.getAgentPosition(opponents[1])
		self.capsules = gameState.getBlueCapsules()
		self.my_pac_pos = gameState.getAgentPosition(self.my_pac)
		self.my_ghost_pos = gameState.getAgentPosition(self.my_ghost)
		self.distance_to_opp1 = self.distancer.getDistance(self.my_pac_pos, self.opp1_pos)
		self.distance_to_opp2 = self.distancer.getDistance(self.my_pac_pos, self.opp2_pos)
		self.distance_my_ghost_my_pac = self.distancer.getDistance(self.my_pac_pos, self.my_ghost_pos)
		if self.opp1_pos[0] - self.my_pac_start_pos[0] < self.mid_red[0]:
			self.opp_off_agent = opponents[0]
			self.opp_def_agent = opponents[1]
		else:
			self.opp_off_agent = opponents[1]
			self.opp_def_agent = opponents[0]
		self.opp_off_agent_pos = gameState.getAgentPosition(self.opp_off_agent)
		self.opp_def_agent_pos = gameState.getAgentPosition(self.opp_def_agent)
		self.distance_to_off_agent = self.distancer.getDistance(self.my_pac_pos, self.opp_off_agent_pos)
		self.distance_to_def_agent = self.distancer.getDistance(self.my_pac_pos, self.opp_def_agent_pos)


		if len(all_food_ours) < 21:
			all_dist = []
			for a in actions:
				succ = gameState.generateSuccessor(self.my_ghost,a)
				pos = succ.getAgentState(self.my_ghost).getPosition()
				self.opp_off_agent_pos = gameState.getAgentPosition(self.opp_off_agent)
				all_dist.append(self.distancer.getDistance(pos,self.opp_off_agent_pos))
			return actions[all_dist.index(min(all_dist))]
		elif len(all_food) > 0 and self.num_food_eaten <= 1 and self.distance_to_def_agent > 5:
			min_dist_values = []
			for a in actions:
				succ = gameState.generateSuccessor(self.my_ghost,a)
				pos = succ.getAgentState(self.my_ghost).getPosition()
				all_dist = []
				for food in all_food:
					all_dist.append(self.distancer.getDistance(food, pos))
				min_dist_values.append(min(all_dist))
			if gameState.generateSuccessor(self.my_ghost,actions[min_dist_values.index(min(min_dist_values))]).getAgentState(self.my_ghost).getPosition() in all_food:
				self.num_food_eaten += 1
			return actions[min_dist_values.index(min(min_dist_values))]
		else:
			dist_values = []
			for a in actions:
				succ = gameState.generateSuccessor(self.my_ghost,a)
				pos = succ.getAgentState(self.my_ghost).getPosition()
				dist_values.append(self.distancer.getDistance(self.mid_red, pos))
				if actions[dist_values.index(min(dist_values))] == 'Stop':
					self.num_food_eaten = 0
			return actions[dist_values.index(min(dist_values))]
			'''min_dist_values = []
			for a in actions:
				succ = gameState.generateSuccessor(self.my_ghost,a)
				pos = succ.getAgentState(self.my_ghost).getPosition()
				all_dist = []
				for food in all_food:
					all_dist.append(self.distancer.getDistance(food, pos))
				min_dist_values.append(min(all_dist))
			return actions[min_dist_values.index(min(min_dist_values))]'''

			'''min_dist_values = []
			for a in actions:
				succ = gameState.generateSuccessor(self.my_ghost,a)
				pos = succ.getAgentState(self.my_ghost).getPosition()
				all_dist = []
				for food in all_food_ours:
					all_dist.append(self.distancer.getDistance(food, pos))
				min_dist_values.append(min(all_dist))
			return actions[min_dist_values.index(min(min_dist_values))]'''




