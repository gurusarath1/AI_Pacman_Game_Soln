# myTeam.py
# ---------
# Licensing Information:	You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


from captureAgents import CaptureAgent
import random, time, util
from game import Directions
import game

#################
# Team creation #
#################

def createTeam(firstIndex, secondIndex, isRed,
							 first = 'AgentGS', second = 'AgentGS'):
	"""
	This function should return a list of two agents that will form the
	team, initialized using firstIndex and secondIndex as their agent
	index numbers.	isRed is True if the red team is being created, and
	will be False if the blue team is being created.

	As a potentially helpful development aid, this function can take
	additional string-valued keyword arguments ("first" and "second" are
	such arguments in the case of this function), which will come from
	the --redOpts and --blueOpts command-line arguments to capture.py.
	For the nightly contest, however, your team will be created without
	any extra arguments, so you should make sure that the default
	behavior is what you want for the nightly contest.
	"""

	# The following line is an example only; feel free to change it.
	return [eval(first)(firstIndex), eval(second)(secondIndex)]

##########
# Agents #
##########

class AgentGS(CaptureAgent):
	"""
	A Dummy agent to serve as an example of the necessary agent structure.
	You should look at baselineTeam.py for more details about how to
	create an agent as this is the bare minimum.
	"""

	GlobalActionSeq = []
	attacker = None

	def registerInitialState(self, gameState):
		"""
		This method handles the initial setup of the
		agent to populate useful fields (such as what team
		we're on).

		A distanceCalculator instance caches the maze distances
		between each pair of positions, so your agents can use:
		self.distancer.getDistance(p1, p2)

		IMPORTANT: This method may run for at most 15 seconds.
		"""

		'''
		Make sure you do not delete the following line. If you would like to
		use Manhattan distances instead of maze distances in order to save
		on initialization time, please take a look at
		CaptureAgent.registerInitialState in captureAgents.py.
		'''
		CaptureAgent.registerInitialState(self, gameState)


		self.firstIteration = True

		self.team = self.getTeam(gameState)
		self.startPos = gameState.getAgentPosition(self.index)
		self.opponent = self.getOpponents(gameState)
		self.endPos = gameState.getAgentPosition(self.opponent[0])
		self.DefendingFood = self.getFoodYouAreDefending(gameState).asList()
		self.numDefendingFood = len(self.DefendingFood)
		self.foodEaten = 0

		if self.startPos[0] > self.endPos[0]:
			self.maxX = self.startPos[0]
		else:
			self.maxX = self.endPos[0]

		if self.startPos[1] > self.endPos[1]:
			self.maxY = self.startPos[1]
		else:
			self.maxY = self.endPos[1]

		self.borderX = int(self.maxX / 2)


		AgentGS.attacker = self.team[0]

		self.Boundary = [  (self.borderX, y) for y in range(1,self.maxY+1) ]
		self.OpenBoundaryList = []

		for b in self.Boundary:
			if not gameState.hasWall(b[0], b[1]):
				self.OpenBoundaryList.append(b)


		caps = gameState.getCapsules()
		self.MyCaps = []
		for cap in caps:
			if not self.mySideOfBoard(cap):
				self.MyCaps.append(cap)


		self.foodTarget = None

		#print(self.OpenBoundaryList)

		#print('Boundary= ', self.Boundary)
		#print('Open Boundary= ', self.OpenBoundaryList)
		#print('StartPoint= ', self.startPos)
		#print('EndPoint= ', self.endPos)
		#print('MyTeam= ', self.team)
		#print('OtherTeam= ', self.opponent)
		#print('My caps= ', self.MyCaps)



	def chooseAction(self, gameState):

		#print('\n', self.index,'===============================')

		self.MyCurrentPos = gameState.getAgentPosition(self.index)

		if self.index == self.team[0]:
			self.MyPartner = self.team[1]
		else:
			self.MyPartner = self.team[0]

		self.MyPartnerPos = gameState.getAgentPosition(self.MyPartner)
		self.currentMyFoods = self.getFood(gameState).asList()
		self.currentDefendingFood = self.getFoodYouAreDefending(gameState).asList()
		self.CurrentNumDefendingFood = len(self.currentDefendingFood)

		#-------------------------------------------------------------------------------------------

		self.distancer.getMazeDistances()

		GhostPos1 = gameState.getAgentPosition(self.opponent[0])
		GhostPos2 = gameState.getAgentPosition(self.opponent[1])
		GhostDist1_toMe = self.getMazeDistance(self.MyCurrentPos, GhostPos1)
		GhostDist2_toMe = self.getMazeDistance(self.MyCurrentPos, GhostPos2)
		GhostDist1_toPartner = self.getMazeDistance(self.MyPartnerPos, GhostPos1)
		GhostDist2_toPartner = self.getMazeDistance(self.MyPartnerPos, GhostPos2)
		MinGhostDist_toMe = min(GhostDist1_toMe, GhostDist2_toMe)
		MinGhostDist_toPartner = min(GhostDist1_toPartner, GhostDist2_toPartner)

		if MinGhostDist_toMe == GhostDist2_toMe:
			MinDistGhostPos = GhostPos2
		else:
			MinDistGhostPos = GhostPos1


		if MinGhostDist_toPartner == GhostDist2_toPartner:
			MinDistGhostPos_toPartner = GhostPos2
		else:
			MinDistGhostPos_toPartner = GhostPos1


		#-------------------------------------------------------------------------------------------
		if self.MyCurrentPos == self.startPos:
			self.foodEaten = 0

			if self.index == AgentGS.attacker:
				self.target = self.OpenBoundaryList[0]
			else:
				self.target = self.OpenBoundaryList[-1]

			self.targetReached = False

		if self.MyCurrentPos == self.target:
			self.targetReached = True

		
		actions = gameState.getLegalActions(self.index)

		#----------------------------------------------------------------------------------------



		Score = self.actualScore(gameState.getScore())

		if self.index == AgentGS.attacker:
		
			if Score == 1 or Score == 0:
				self.maxFoodToEat = 1
			else:
				self.maxFoodToEat = 2

			

			#if (self.numDefendingFood - self.CurrentNumDefendingFood) > 16:
			if Score > 6 or (self.numDefendingFood - self.CurrentNumDefendingFood) > 7:
				#print('1 - Defend')
				act = self.GreedyDefendingAgent(gameState)
			#elif not self.targetReached:
				#print('0 - Goto Target')
			#	act = self.GreedyAgent_type2(gameState)
			elif MinGhostDist_toMe <= 2:
				#print('0 - Escape')
				act = self.miniMaxAgent(gameState, self.evaluationFunction_GotoExit)
			elif MinGhostDist_toMe < 5 and (not self.mySideOfBoard(MinDistGhostPos)):
				#print('0 - Escape to Exit')
				act = self.miniMaxAgent(gameState, self.evaluationFunction_EscapeTheGhost)
			else:
				#print('0 - Eat greedy')
				act = self.GreedyAgent_type1(gameState)
				

		else:
		
			if Score == 1 or Score == 0:
				self.maxFoodToEat = 1
			else:
				self.maxFoodToEat = 2			

			#if (self.numDefendingFood - self.CurrentNumDefendingFood) > 0:
			#if self.mySideOfBoard(GhostPos1) or self.mySideOfBoard(GhostPos2):
			if (Score > 3 or self.mySideOfBoard(GhostPos1) or self.mySideOfBoard(GhostPos2)):
				#print('1 - Defend')
				act = self.GreedyDefendingAgent(gameState)
			elif not self.targetReached:
				#print('1 - Goto Target')
				act = self.GreedyAgent_type2(gameState)
			elif MinGhostDist_toMe < 5 and (not self.mySideOfBoard(MinDistGhostPos)):
				#print('1 - Escape')
				act = self.miniMaxAgent(gameState, self.evaluationFunction_GotoExit)
			else:
				#print('1 - Eat Greedy')
				act = self.GreedyAgent_type1(gameState)
			


		NextState = gameState.generateSuccessor(self.index, act)
		pacPosAfterAction = NextState.getAgentPosition(self.index)
		if pacPosAfterAction in self.currentMyFoods:
			self.foodEaten += 1

		if pacPosAfterAction in self.MyCaps:
			self.maxFoodToEat = 7



		self.firstIteration = False
		#print(act)
		return act
		
	def actualScore(self, score):
		
		if self.red:
			return score
		else:
			return -score


	def switchAttacker(self):
		if AgentGS.attacker == self.team[0]:
			AgentGS.attacker = self.team[1]
		else:
			AgentGS.attacker = self.team[0]

	def detectStuck(self, seq):

		if seq[0] == seq[2] and seq[1] == seq[3]:
			if seq[0] != seq[1]:
				return True


	def mySideOfBoard(self,Pos):

		if self.red:
			if Pos[0] <= self.borderX:
				return True
			else:
				return False
		else:
			if Pos[0] <= self.borderX:
				return False
			else:
				return True			

	def getPacsOnMySide(self, gameState):

		agentsOnMySide = []

		if gameState.getAgentPosition(self.opponent[0])[0] <= self.borderX and self.red:
			agentsOnMySide.append(self.opponent[0])
		elif gameState.getAgentPosition(self.opponent[0])[0] > self.borderX and not self.red:
			agentsOnMySide.append(self.opponent[0])

		if gameState.getAgentPosition(self.opponent[1])[0] <= self.borderX and self.red:
			agentsOnMySide.append(self.opponent[1])
		elif gameState.getAgentPosition(self.opponent[1])[0] > self.borderX and not self.red:
			agentsOnMySide.append(self.opponent[1])

		return agentsOnMySide

	def getGhostsOnTheirSide(self, gameState):

		agentsOnMySide = []

		if gameState.getAgentPosition(self.opponent[0])[0] > self.borderX:
			agentsOnMySide.append(self.opponent[0])

		if gameState.getAgentPosition(self.opponent[1])[0] > self.borderX:
			agentsOnMySide.append(self.opponent[1])

		return agentsOnMySide

	def opponentNotInMySide(self, gameState):

		if gameState.getAgentPosition(self.opponent[0])[0] <= self.borderX or gameState.getAgentPosition(self.opponent[1])[0] <= self.borderX:
			return False
		else:
			return True

	def euclidDistance(self, pos1, pos2):
		return (pos1[0] - pos2[0])**2 + (pos1[1] - pos2[1])**2

	def GreedyAgent_type1(self, gameState):

		if self.foodEaten < self.maxFoodToEat and self.currentMyFoods:
			#print('Go Eat Greedy')
			act = self.greedyAgentEat(gameState)
		else:
			#print('Go Back')
			act = self.greedyGoBack(gameState)

			if self.mySideOfBoard(self.MyCurrentPos):
				self.foodEaten = 0

		return act

	def GreedyAgent_type3(self, gameState):

		if self.foodEaten < self.maxFoodToEat and self.currentMyFoods:
			#print('Go Eat Greedy')
			act = self.greedyAgentTarget_Farfood(gameState)
		else:
			#print('Go Back')
			act = self.greedyGoBack(gameState)

			if self.mySideOfBoard(self.MyCurrentPos):
				self.foodEaten = 0

		return act


	def GreedyAgent_type2(self, gameState):

		if self.foodEaten < self.maxFoodToEat and self.currentMyFoods:
			#print('Go Eat Greedy')
			act = self.greedyAgentTarget(gameState)
		else:
			#print('Go Back')
			act = self.greedyGoBack(gameState)

			if self.mySideOfBoard(self.MyCurrentPos):
				self.foodEaten = 0

		return act

	def greedyAgentTarget_Farfood(self, gameState):


		if self.MyCurrentPos == self.foodTarget:
			self.foodTarget = None

		if not self.foodTarget:
			ghosts = self.getGhostsOnTheirSide(gameState)

			awayFromGhost = None

			for g in ghosts:
				g_pos = gameState.getAgentPosition(g)
				if not self.mySideOfBoard(g_pos):
					awayFromGhost = g
					break

			if g == None:
				g = random.choice(ghosts)
				g_pos = gameState.getAgentPosition(g)


			maxFoodDist = float('-inf')
			targetFoodPos = random.choice(self.currentMyFoods)
			for food in self.currentMyFoods:

				dist = self.getMazeDistance(food, g_pos)

				if dist > maxFoodDist:
					maxFoodDist = dist
					targetFoodPos = food

			self.foodTarget = targetFoodPos



		actions = gameState.getLegalActions(self.index)
		actions = actions[:-1]

		minDistAct = None
		minDist = float('inf')

		for actX in actions:

			NextState = gameState.generateSuccessor(self.index, actX)
			pacPosAfterAction = NextState.getAgentPosition(self.index)

			dist = self.getMazeDistance(pacPosAfterAction, self.foodTarget)

			if dist < minDist:
				minDist = dist
				minDistAct = actX

		NextState = gameState.generateSuccessor(self.index, minDistAct)
		pacPosAfterAction = NextState.getAgentPosition(self.index)

		return minDistAct


	def greedyGoBack(self, gameState):

		#foodList = self.currentDefendingFood
		pacPosBeforeAct = gameState.getAgentPosition(self.index)
		#nearestFood = self.getNearestThing(pacPosBeforeAct, foodList)
		nearestBoundary = self.getNearestThing(pacPosBeforeAct, self.OpenBoundaryList)


		actions = gameState.getLegalActions(self.index)
		actions = actions[:-1]

		minDistAct = None
		minDist = float('inf')

		for actX in actions:

			NextState = gameState.generateSuccessor(self.index, actX)
			pacPosAfterAction = NextState.getAgentPosition(self.index)

			if self.mySideOfBoard(pacPosAfterAction):
				return actX

			dist = self.getMazeDistance(pacPosAfterAction, nearestBoundary)

			if dist < minDist:
				minDist = dist
				minDistAct = actX

		NextState = gameState.generateSuccessor(self.index, minDistAct)
		pacPosAfterAction = NextState.getAgentPosition(self.index)

		return minDistAct



	def greedyAgentEat(self, gameState):

		
		foodList = self.currentMyFoods
		pacPosBeforeAct = gameState.getAgentPosition(self.index)
		nearestFood = self.getNearestThing(pacPosBeforeAct, foodList)

		actions = gameState.getLegalActions(self.index)
		actions = actions[:-1]

		minDistAct = None
		minDist = float('inf')

		for actX in actions:

			NextState = gameState.generateSuccessor(self.index, actX)
			pacPosAfterAction = NextState.getAgentPosition(self.index)

			dist = self.getMazeDistance(pacPosAfterAction, nearestFood)

			if dist < minDist:
				minDist = dist
				minDistAct = actX

		NextState = gameState.generateSuccessor(self.index, minDistAct)
		pacPosAfterAction = NextState.getAgentPosition(self.index)

		return minDistAct

	def greedyAgentTarget(self, gameState):

		actions = gameState.getLegalActions(self.index)
		actions = actions[:-1]

		minDistAct = None
		minDist = float('inf')

		for actX in actions:

			NextState = gameState.generateSuccessor(self.index, actX)
			pacPosAfterAction = NextState.getAgentPosition(self.index)

			dist = self.getMazeDistance(pacPosAfterAction, self.target)

			if dist < minDist:
				minDist = dist
				minDistAct = actX

		NextState = gameState.generateSuccessor(self.index, minDistAct)
		pacPosAfterAction = NextState.getAgentPosition(self.index)

		return minDistAct


	def getNearestThing(self, pacPos, FoodList):

		minDist = float('inf')
		MinPos = None

		for foodPosX in FoodList:

			dist = self.getMazeDistance(pacPos, foodPosX)

			if dist < minDist:
				minDist = dist
				MinPos = foodPosX

		return MinPos



	def getaverageDistance(self, currrentPost, AllOtherPosList):

		val = 0

		for pos in AllOtherPosList:
				val += self.getMazeDistance(currrentPost, pos)

		return val / (len(AllOtherPosList) + 1)


	def PartiallyDefendingAgent(self,gameState, eatingAgent, pureDefendingAgent):

		if self.opponentNotInMySide(gameState):
			act = eatingAgent(gameState)
		else:
			act = pureDefendingAgent(gameState)

		return act

	def GreedyDefendingAgent(self, gameState):

		pacs = self.getPacsOnMySide(gameState)

		if not pacs:
			return 'Stop'

		TargetPac = pacs[0]
		TargetPacLoc = gameState.getAgentPosition(TargetPac)

		actions = gameState.getLegalActions(self.index)
		actions = actions[:-1]
		minDistAct = None
		minDist = float('inf')

		for actX in actions:

			NextState = gameState.generateSuccessor(self.index, actX)
			pacPosAfterAction = NextState.getAgentPosition(self.index)

			dist = self.getMazeDistance(pacPosAfterAction, TargetPacLoc)

			if dist < minDist:
				minDist = dist
				minDistAct = actX

		return minDistAct



	def miniMaxAgent(self, gameState, evalFunc):
		"""
		Returns the expectimax action using self.depth and self.evaluationFunction_EscapeTheGhost

		All ghosts should be modeled as choosing uniformly at random from their
		legal moves.
		"""
		NextAgentX = self.NextAgent(self.index)
		NextActions = gameState.getLegalActions(self.index)
		NextActions = NextActions[:-1]

		#currentNumberOfFood = len(CaptureAgent.getFood(self,gameState).asList())
		
		MaxVal = float('-inf')
		MaxAct = None
		for actX in NextActions:
			StateX = gameState.generateSuccessor(self.index, actX)

			#NextNumberOfFood = len(CaptureAgent.getFood(self,StateX).asList())

			#if (currentNumberOfFood - NextNumberOfFood) == 1:
			#	return actX

			Val = self.MinNode(StateX, 4, NextAgentX, evalFunc)
			if MaxVal < Val:
				MaxVal = Val
				MaxAct  = actX

		#print(MaxAct)
		
		return MaxAct
				
	def MaxNode(self, gameState, depth, agentIndex, evalFunc):
	
		##print('Max Node', depth, agentIndex)
		#Decrement depth only if the agent is pacman
		depth = depth - 1

		#Terminal test
		if depth == 0:
			return evalFunc(gameState)
		
		NextAgentX = self.NextAgent(agentIndex)
		NextActions = gameState.getLegalActions(agentIndex)
		NextActions = NextActions[:-1]
		
		MaxVal = float('-inf')
		MaxAct = None
		
		for actX in NextActions:
			StateX = gameState.generateSuccessor(agentIndex, actX)
			Val = self.MinNode(StateX, depth, NextAgentX, evalFunc)
			if MaxVal < Val:
				MaxVal = Val
				MaxAct  = actX
		
		return MaxVal
				
	def ExpectiNode(self, gameState, depth, agentIndex, evalFunc):
	
		##print('Min Node', depth, agentIndex)
		#Decrement depth only if the agent is pacman

		depth = depth - 1
		#Terminal test
		if depth == 0:
			return evalFunc(gameState)
		
		NextAgentX = self.NextAgent(agentIndex)
		NextActions = gameState.getLegalActions(agentIndex)
		
		MinVal = float('inf')
		MinAct = None
		Sum = 0 #Sum of utilities of all states
		
		#Uniform probability distribution
		p = 1 / len(NextActions)
		
		for actX in NextActions:

			StateX = gameState.generateSuccessor(agentIndex, actX)
			
			if NextAgentX == self.index:
				Val = self.MaxNode(StateX, depth, NextAgentX, evalFunc)
			else:
				Val = self.ExpectiNode(StateX, depth, NextAgentX, evalFunc)
				
			Sum += Val
		
		return Sum * p

	def MinNode(self, gameState, depth, agentIndex, evalFunc):
	
		##print('Min Node', depth, agentIndex)
		#Decrement depth only if the agent is pacman

		depth = depth - 1
		#Terminal test
		if depth == 0:
			return evalFunc(gameState)
		
		NextAgentX = self.NextAgent(agentIndex)
		NextActions = gameState.getLegalActions(agentIndex)
		NextActions = NextActions[:-1]
		
		MinVal = float('inf')
		MinAct = None
		Sum = 0 #Sum of utilities of all states
		
		#Uniform probability distribution
		p = 1 / len(NextActions)
		
		for actX in NextActions:

			StateX = gameState.generateSuccessor(agentIndex, actX)
			
			if NextAgentX == self.index:
				Val = self.MaxNode(StateX, depth, NextAgentX, evalFunc)
			else:
				Val = self.MinNode(StateX, depth, NextAgentX, evalFunc)
				
			if Val < MinVal:
				MinVal = Val
				MinAct = actX
		
		return MinVal
	
	#Function that returns the next agent index	
	def NextAgent(self, agentIndex):

		if agentIndex == self.index:
			return self.opponent[0]
		
		if agentIndex == self.opponent[0]:
			return self.opponent[1]

		if agentIndex == self.opponent[1]:
			return self.index


	def montecarloAgent(self, gameState):

		depth = 10
		iterations = 200

		actions = gameState.getLegalActions(self.index)
		actions = actions[:-1]
		ActionQ = util.Counter()

		for act in actions:

			nextState = gameState.generateSuccessor(self.index ,act)
			ActionQ[act] = self.evaluationFunction_EscapeTheGhost(nextState)

			nextAgentIndex = self.NextAgent(self.index)

			for i in range(iterations):

				for j in range(depth):
					actsX = nextState.getLegalActions(nextAgentIndex)
					actsX = actsX[:-1]
					nextState = nextState.generateSuccessor(nextAgentIndex , random.choice(actsX))
					nextAgentIndex = self.NextAgent(nextAgentIndex)

					ActionQ[act] += self.evaluationFunction_EscapeTheGhost(nextState)


		#print(ActionQ)

		returnAct = ActionQ.argMax()

		#print(returnAct)

		return returnAct

	def evaluationFunction_EscapeTheGhost(self, gameState):

		MyPos = gameState.getAgentPosition(self.index)
		GhostPos1 = gameState.getAgentPosition(self.opponent[0])
		GhostPos2 = gameState.getAgentPosition(self.opponent[1])

		GhostDist1 = self.getMazeDistance(MyPos, GhostPos1)
		GhostDist2 = self.getMazeDistance(MyPos, GhostPos2)

		GhostDist = min(GhostDist1, GhostDist2)

		Score = self.actualScore(gameState.getScore())

		Side = 0
		if self.mySideOfBoard(MyPos):
			Side = 0
		else:
			Side = 1

		NumFood = 0
		FoodDist = 0
		FoodList = CaptureAgent.getFood(self,gameState).asList()
		
		NumFood = len(FoodList)
		FoodDist = self.getaverageDistance(MyPos, FoodList)


		##print(GhostDist, ' - ', Side,' - ',NumFood,' - ',Score,' - ',FoodDist)

		if self.mySideOfBoard(MyPos):
			myside = 80
		else:
			myside = 0


		walls = gameState.getWalls().asList()
		NumWalls = 5 - len(gameState.getLegalActions())

		if self.MyCaps[0] in gameState.getCapsules():
			distTocaps = self.getMazeDistance(MyPos, self.MyCaps[0])
		else:
			distTocaps = 0

		##print("NumWalls - ", (-1000* NumWalls))
		##print("distTocaps - ", (-100 * distTocaps))
		##print("NumFood - ", (-20 * NumFood))
		##print("Score - ", (100* Score))
		#f = (-20 * GhostDist) + Score + (20*(20 - NumFood)) + myside
		#f =  (-1000* NumWalls) + (-10 * distTocaps) + (-20 * NumFood) + (100 * Score) + (2000 * GhostDist)

		f =0

		if GhostDist > 2:
			f = (-FoodDist) + (-NumFood) + (-100*NumWalls) + (-distTocaps)

		if MyPos == self.startPos  or MyPos == GhostPos2 or MyPos == GhostPos1:
			##print('Died')
			f = -100000

		f = (-10 * GhostDist) + Score + (-10 * NumWalls) + (-10 * distTocaps)

		#f = (-10 * GhostDist) + Score + (-50 * NumWalls) + (-10 * distTocaps) + (-FoodDist)

		return f

	def evaluationFunction_GotoExit(self, gameState):
		MyPos = gameState.getAgentPosition(self.index)
		GhostPos1 = gameState.getAgentPosition(self.opponent[0])
		GhostPos2 = gameState.getAgentPosition(self.opponent[1])

		GhostDist1 = self.getMazeDistance(MyPos, GhostPos1)
		GhostDist2 = self.getMazeDistance(MyPos, GhostPos2)

		GhostDist = min(GhostDist1, GhostDist2)

		Score = self.actualScore(gameState.getScore())

		Side = 0
		if self.mySideOfBoard(MyPos):
			Side = 0
		else:
			Side = 1

		NumFood = 0
		FoodDist = 0
		FoodList = CaptureAgent.getFood(self,gameState).asList()
		
		NumFood = len(FoodList)
		FoodDist = self.getaverageDistance(MyPos, FoodList)


		##print(GhostDist, ' - ', Side,' - ',NumFood,' - ',Score,' - ',FoodDist)

		if self.mySideOfBoard(MyPos):
			myside = 80
		else:
			myside = 0


		walls = gameState.getWalls().asList()
		NumWalls = 5 - len(gameState.getLegalActions())

		if self.MyCaps[0] in gameState.getCapsules():
			distTocaps = self.getMazeDistance(MyPos, self.MyCaps[0])
		else:
			distTocaps = 0

		if self.red:
			distToBorder = MyPos[0] - self.borderX
		else:
			distToBorder = -MyPos[0] + self.borderX

		f = (-30 * GhostDist) + Score + (-20 * NumWalls) + (-10 * distToBorder)

		return f








