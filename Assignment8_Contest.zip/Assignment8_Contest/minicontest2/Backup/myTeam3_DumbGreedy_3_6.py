# myTeam.py
# ---------
# Licensing Information:	You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


from captureAgents import CaptureAgent
import random, time, util
from game import Directions
import game

#################
# Team creation #
#################

def createTeam(firstIndex, secondIndex, isRed,
							 first = 'AgentGS', second = 'AgentGS'):
	"""
	This function should return a list of two agents that will form the
	team, initialized using firstIndex and secondIndex as their agent
	index numbers.	isRed is True if the red team is being created, and
	will be False if the blue team is being created.

	As a potentially helpful development aid, this function can take
	additional string-valued keyword arguments ("first" and "second" are
	such arguments in the case of this function), which will come from
	the --redOpts and --blueOpts command-line arguments to capture.py.
	For the nightly contest, however, your team will be created without
	any extra arguments, so you should make sure that the default
	behavior is what you want for the nightly contest.
	"""

	# The following line is an example only; feel free to change it.
	return [eval(first)(firstIndex), eval(second)(secondIndex)]

##########
# Agents #
##########

class AgentGS(CaptureAgent):
	"""
	A Dummy agent to serve as an example of the necessary agent structure.
	You should look at baselineTeam.py for more details about how to
	create an agent as this is the bare minimum.
	"""

	def registerInitialState(self, gameState):
		"""
		This method handles the initial setup of the
		agent to populate useful fields (such as what team
		we're on).

		A distanceCalculator instance caches the maze distances
		between each pair of positions, so your agents can use:
		self.distancer.getDistance(p1, p2)

		IMPORTANT: This method may run for at most 15 seconds.
		"""

		'''
		Make sure you do not delete the following line. If you would like to
		use Manhattan distances instead of maze distances in order to save
		on initialization time, please take a look at
		CaptureAgent.registerInitialState in captureAgents.py.
		'''
		CaptureAgent.registerInitialState(self, gameState)


		self.team = self.getTeam(gameState)
		self.startPos = gameState.getAgentPosition(self.index)
		self.opponent = self.getOpponents(gameState)
		self.endPos = gameState.getAgentPosition(self.opponent[0])
		self.foodEaten = 0

		if self.startPos[0] > self.endPos[0]:
			self.maxX = self.startPos[0]
		else:
			self.maxX = self.endPos[0]

		if self.startPos[1] > self.endPos[1]:
			self.maxY = self.startPos[1]
		else:
			self.maxY = self.endPos[1]

		self.borderX = int(self.maxX / 2)




		self.Boundary = [  (self.borderX, y) for y in range(1,self.maxY) ]


		print('Boundary= ', self.Boundary)
		print('StartPoint= ', self.startPos)
		print('EndPoint= ', self.endPos)
		print('MyTeam = ', self.team)
		print('OtherTeam = ', self.opponent)
		

		'''
		Your initialization code goes here, if you need any.
		'''


	def chooseAction(self, gameState):
		"""
		Picks among actions randomly.
		"""	
		print('\n', self.index,'===============================')
		actions = gameState.getLegalActions(self.index)
		'''
		You should change this in your own agent.
		'''
		#print(self.getCurrentObservation())

		self.currentPos = gameState.getAgentPosition(self.index)
		self.currentMyFood = self.getFood(gameState).asList()
		self.currentDefendingFood = self.getFoodYouAreDefending(gameState).asList()

		print('CurrentPos = ', self.currentPos)

		if self.currentPos == self.startPos:
			self.foodEaten = 0



		self.distancer.getMazeDistances()

		if self.index == self.team[0]:

			act = self.GreedyAgent_type1(gameState)

		else:

			act = self.PartiallyDefendingAgent(gameState, self.GreedyAgent_type1, self.GreedyDefendingAgent)



		print('\n================================')

		return act


	def mySideOfBoard(self,Pos):

		if Pos[0] <= self.borderX:
			return True
		else:
			return False

	def GreedyAgent_type1(self, gameState):

		if self.foodEaten < 1 and self.currentMyFood:
			print('Go Eat')
			act = self.greedyAgentEat(gameState)
		else:
			print('Go Back')
			act = self.greedyGoBack(gameState)

			if self.mySideOfBoard(self.currentPos):
				self.foodEaten = 0

		return act



	def greedyGoBack(self, gameState):

		foodList = self.currentDefendingFood
		pacPosBeforeAct = gameState.getAgentPosition(self.index)
		nearestFood = self.getNearestFood(pacPosBeforeAct, foodList)

		actions = gameState.getLegalActions(self.index)

		minDistAct = None
		minDist = float('inf')

		for actX in actions:

			NextState = gameState.generateSuccessor(self.index, actX)
			pacPosAfterAction = NextState.getAgentPosition(self.index)

			if self.mySideOfBoard(pacPosAfterAction):
				return actX

			dist = self.getMazeDistance(pacPosAfterAction, nearestFood)

			if dist < minDist:
				minDist = dist
				minDistAct = actX

		NextState = gameState.generateSuccessor(self.index, minDistAct)
		pacPosAfterAction = NextState.getAgentPosition(self.index)

		return minDistAct



	def greedyAgentEat(self, gameState):

		
		foodList = self.currentMyFood
		pacPosBeforeAct = gameState.getAgentPosition(self.index)
		nearestFood = self.getNearestFood(pacPosBeforeAct, foodList)

		actions = gameState.getLegalActions(self.index)

		minDistAct = None
		minDist = float('inf')

		for actX in actions:

			NextState = gameState.generateSuccessor(self.index, actX)
			pacPosAfterAction = NextState.getAgentPosition(self.index)

			dist = self.getMazeDistance(pacPosAfterAction, nearestFood)

			if dist < minDist:
				minDist = dist
				minDistAct = actX

		NextState = gameState.generateSuccessor(self.index, minDistAct)
		pacPosAfterAction = NextState.getAgentPosition(self.index)

		if pacPosAfterAction in foodList:
			self.foodEaten += 1

		return minDistAct



	def getNearestFood(self, pacPos, FoodList):

		minDist = float('inf')
		MinPos = None

		for foodPosX in FoodList:

			dist = self.getMazeDistance(pacPos, foodPosX)

			if dist < minDist:
				minDist = dist
				MinPos = foodPosX

		return MinPos



	def getaverageDistance(self, currrentPost, AllOtherPosList):

		val = 0

		for pos in AllOtherPosList:
				val += self.getMazeDistance(currrentPost, pos)

		return val / len(AllOtherPosList)


	def opponentNotInMySide(self, gameState):

		if gameState.getAgentPosition(self.opponent[0])[0] <= self.borderX or gameState.getAgentPosition(self.opponent[1])[0] <= self.borderX:
			return False
		else:
			return True


	def getPacsOnMySide(self, gameState):

		agentsOnMySide = []

		if gameState.getAgentPosition(self.opponent[0])[0] <= self.borderX:
			agentsOnMySide.append(self.opponent[0])

		if gameState.getAgentPosition(self.opponent[1])[0] <= self.borderX:
			agentsOnMySide.append(self.opponent[1])

		return agentsOnMySide


	def PartiallyDefendingAgent(self,gameState, eatingAgent, pureDefendingAgent):

		if self.opponentNotInMySide(gameState):
			act = eatingAgent(gameState)
		else:
			act = pureDefendingAgent(gameState)

		return act

	def GreedyDefendingAgent(self, gameState):

		pacs = self.getPacsOnMySide(gameState)

		if not pacs:
			return 'Stop'

		TargetPac = pacs[0]
		TargetPacLoc = gameState.getAgentPosition(TargetPac)

		actions = gameState.getLegalActions(self.index)
		minDistAct = None
		minDist = float('inf')

		for actX in actions:

			NextState = gameState.generateSuccessor(self.index, actX)
			pacPosAfterAction = NextState.getAgentPosition(self.index)

			dist = self.getMazeDistance(pacPosAfterAction, TargetPacLoc)

			if dist < minDist:
				minDist = dist
				minDistAct = actX

		return minDistAct







