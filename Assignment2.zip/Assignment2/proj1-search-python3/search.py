# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util

class SearchProblem:
	"""
	This class outlines the structure of a search problem, but doesn't implement
	any of the methods (in object-oriented terminology: an abstract class).

	You do not need to change anything in this class, ever.
	"""

	def getStartState(self):
		"""
		Returns the start state for the search problem.
		"""
		util.raiseNotDefined()

	def isGoalState(self, state):
		"""
		  state: Search state

		Returns True if and only if the state is a valid goal state.
		"""
		util.raiseNotDefined()

	def getSuccessors(self, state):
		"""
		  state: Search state

		For a given state, this should return a list of triples, (successor,
		action, stepCost), where 'successor' is a successor to the current
		state, 'action' is the action required to get there, and 'stepCost' is
		the incremental cost of expanding to that successor.
		"""
		util.raiseNotDefined()

	def getCostOfActions(self, actions):
		"""
		 actions: A list of actions to take

		This method returns the total cost of a particular sequence of actions.
		The sequence must be composed of legal moves.
		"""
		util.raiseNotDefined()


def tinyMazeSearch(problem):
	"""
	Returns a sequence of moves that solves tinyMaze.  For any other maze, the
	sequence of moves will be incorrect, so only use this for tinyMaze.
	"""
	from game import Directions
	s = Directions.SOUTH
	w = Directions.WEST
	return  [s, s, w, s, w, w, s, w]

def depthFirstSearch(problem):
	"""
	Search the deepest nodes in the search tree first.

	Your search algorithm needs to return a list of actions that reaches the
	goal. Make sure to implement a graph search algorithm.

	To get started, you might want to try some of these simple commands to
	understand the search problem that is being passed in:

	print("Start:", problem.getStartState())
	print("Is the start a goal?", problem.isGoalState(problem.getStartState()))
	print("Start's successors:", problem.getSuccessors(problem.getStartState()))
	"""
	# Guru Sarath
    # UIN: 829009551
    
	# Initialize values to start DFS
	start_State = problem.getStartState()
	GoalState =  None
	
	current_state = None
	Prev_state = None
	openList = util.Stack() # List of unexplored states
	visited_set = set() # Set of visited states 
	CameFrom = {(start_State,): None} # Used to reconstruct path
	SolutionActions_Sequence = [] # Sequence of actions to reach goal
	SolutionState_Sequence = [] # Sequence of states to reach goal
	GoalFound = False # Flag to check if goal was reached
	
	# Push the start state to unexplored states list
	openList.push(start_State)
	
	# Main Search loop
	while not openList.isEmpty():
	
		current_state  = openList.pop()

		# Check if the current state is a goal state
		if problem.isGoalState(current_state):
			GoalFound = True
			break

		visited_set.add(current_state) #Add the current node to explored set
		
		NextStates = problem.getSuccessors(current_state)
		NextStates = NextStates[::-1]
		
		for StateX, ActionX, CostX in NextStates:
			# Generate successor only if it is not present in the visited set
			if StateX not in visited_set:
				openList.push(StateX)
				CameFrom[StateX] = (current_state, ActionX)	# Used for path reconstruction
		
	if not GoalFound:
		# If no goal was found return empty list
		return []	
	
	GoalState = current_state
	SolutionState_Sequence.append(GoalState)
	
	#print('Goal reached')
	
	# Reconstruct path
	while current_state != start_State:
		SolutionState_Sequence.append(CameFrom[current_state][0])
		SolutionActions_Sequence.append(CameFrom[current_state][1])
		current_state = CameFrom[current_state][0]
		
	SolutionActions_Sequence = SolutionActions_Sequence[::-1]
				
	return SolutionActions_Sequence

def breadthFirstSearch(problem):
	"""Search the shallowest nodes in the search tree first."""
	
	start_State = problem.getStartState()
	GoalState =  None
	
	current_state = None
	Prev_state = None
	openList = util.Queue() # List of unexplored states
	visited_set = set() # Set of visited states 
	CameFrom = {(start_State,): None} # Used to reconstruct path
	SolutionActions_Sequence = [] # Sequence of actions to reach goal
	SolutionState_Sequence = [] # Sequence of states to reach goal
	GoalFound = False # Flag to check if goal was reached
	
	# Push the start state to unexplored states list
	openList.push(start_State)
	
	# Main Search loop
	while not openList.isEmpty():
		current_state  = openList.pop()

		# Check if the current state is a goal state
		if problem.isGoalState(current_state):
			GoalFound = True
			break

		visited_set.add(current_state) #Add the current node to explored set
		
		NextStates = problem.getSuccessors(current_state)
		
		for StateX, ActionX, CostX in NextStates:
			#if StateX not in openList.list:
			if StateX not in visited_set and StateX not in openList.list:
				openList.push(StateX)
				CameFrom[StateX] = (current_state, ActionX)
				
	if not GoalFound:
	# If no goal was found return empty list
		return []
		
	GoalState = current_state
	SolutionState_Sequence.append(GoalState)
	
	# Reconstruct path
	while current_state != start_State:
		SolutionState_Sequence.append(CameFrom[current_state][0])
		SolutionActions_Sequence.append(CameFrom[current_state][1])
		current_state = CameFrom[current_state][0]
		
	SolutionActions_Sequence = SolutionActions_Sequence[::-1]
	return SolutionActions_Sequence

	
def uniformCostSearch(problem):
	start_State = problem.getStartState()
	GoalState =  None
	
	current_state = None
	Prev_state = None
	openList = util.PriorityQueue() # List of unexplored states
	visited_set = set() # Set of visited states 
	CameFrom = {(start_State,): None} # Used to reconstruct path
	SolutionActions_Sequence = [] # Sequence of actions to reach goal
	SolutionState_Sequence = [] # Sequence of states to reach goal
	GoalFound = False # Flag to check if goal was reached
	
	# Push the start state to unexplored states list
	openList.update(start_State,0)
	Current_Cost = 0
	
	# Main Search loop
	while not openList.isEmpty():
		
		openList_heap = openList.heap[:]
		current_state = openList.pop()
		
		Current_Cost = 0
		for elementX in openList_heap:
			if current_state == elementX[2]:
				Current_Cost += elementX[0]
		
		# Check if the current state is a goal state
		if problem.isGoalState(current_state):
			GoalFound = True
			break
		
		NextStates = problem.getSuccessors(current_state)
		visited_set.add(current_state) #Add the current node to explored set
		
		PriorityList_elements = []
		for state_tuple in openList.heap:
				PriorityList_elements.append(state_tuple[2])
		
		# Iterate through all successors states
		for StateX, ActionX, CostX in NextStates:

			if StateX not in visited_set and StateX not in PriorityList_elements:
				openList.push(StateX, Current_Cost + CostX)
				CameFrom[StateX] = (current_state, ActionX)
				
			elif StateX not in visited_set and StateX in PriorityList_elements :
				for state_tuple in openList.heap:
					if state_tuple[2] == StateX:
						prevCost = state_tuple[0]
						break
			
				if CostX < prevCost:
					openList.update(StateX, Current_Cost + CostX)
					CameFrom[StateX] = (current_state, ActionX)
	
	
	if not GoalFound:
	# If no goal was found return empty list
		return []
	
	GoalState = current_state
	SolutionState_Sequence.append(GoalState)
	
	# Reconstruct path
	while current_state != start_State:
		SolutionState_Sequence.append(CameFrom[current_state][0])
		SolutionActions_Sequence.append(CameFrom[current_state][1])
		current_state = CameFrom[current_state][0]
		
	SolutionActions_Sequence = SolutionActions_Sequence[::-1]
				
	return SolutionActions_Sequence

def nullHeuristic(state, problem=None):
	"""
	A heuristic function estimates the cost from the current state to the nearest
	goal in the provided SearchProblem.  This heuristic is trivial.
	"""
	return 0

def aStarSearch(problem, heuristic=nullHeuristic):
	"""Search the node that has the lowest combined cost and heuristic first."""
	start_State = problem.getStartState()
	GoalState =  None
	
	current_state = None
	Prev_state = None
	openList = [] # List of unexplored states
	g_score = {start_State:0} # Cost to reach a node from start
	visited_set = set() # Set of visited states 
	CameFrom = {start_State: None} # Used to reconstruct path
	SolutionActions_Sequence = [] # Sequence of actions to reach goal
	SolutionState_Sequence = [] # Sequence of states to reach goal
	GoalFound = False # Flag to check if goal was reached
	
	# Push the start state to unexplored states list
	openList = [start_State] 
	
	# Function to return least cost node (based on f score) from open list and its g score
	def returnLeastCostState(StateList, g_score_dict):
		leastCost = float('inf')
		leastCostNode = None
		
		for stateX in StateList:
			#f score = g + h
			f_score = (g_score_dict[stateX] + heuristic(stateX, problem))
			if f_score < leastCost:
				g = g_score_dict[stateX]
				leastCost = f_score
				leastCostNode = stateX
				
		StateList.remove(leastCostNode)	
		
		return leastCostNode, g
				
	
	while openList:
		
		# Get the least cost (f score cost) node form the open list 
		# also get its g score
		current_state, Current_Cost = returnLeastCostState(openList, g_score)
		visited_set.add(current_state) #Add the node to explored list
		
		# Check if the current state is a goal state
		if problem.isGoalState(current_state):
			GoalFound = True
			break
			
		NextStates = problem.getSuccessors(current_state)
		
		# Iterate through all successors states
		for StateX, ActionX, CostX in NextStates:
			
			# Add a state directly to the open list only if it is not in visited set and in open list
			if StateX not in visited_set and StateX not in openList:
				g_score[StateX] = CostX + Current_Cost
				openList.append(StateX)
				CameFrom[StateX] = (current_state, ActionX)
			# Update the camefrom information of a state is it is not already present in open list and has a lower cost
			elif StateX not in visited_set and StateX in openList and  g_score[StateX] > (CostX + Current_Cost):
				g_score[StateX] = CostX + Current_Cost
				CameFrom[StateX] = (current_state, ActionX)
				
	if not GoalFound:
		# If no goal was found return empty list
		return []
	
	GoalState = current_state
	SolutionState_Sequence.append(GoalState)
	
	while current_state != start_State:
		SolutionState_Sequence.append(CameFrom[current_state][0])
		SolutionActions_Sequence.append(CameFrom[current_state][1])
		current_state = CameFrom[current_state][0]
		
	SolutionActions_Sequence = SolutionActions_Sequence[::-1]
				
	return SolutionActions_Sequence


# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
